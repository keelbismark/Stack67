# ──────────────────────────────────────────────────────────────────────
# Функция apply_stack_67.mcfunction — ручной запуск
# ──────────────────────────────────────────────────────────────────────
#
# Одноразовая обработка инвентаря. Можно запустить вручную:
#   /function stack67:apply_stack_67
#
# Отличается от periodic.mcfunction тем, что НЕ перезапускает себя.

execute as @a run item modify entity @s hotbar.0 stack67:set_stack_67
execute as @a run item modify entity @s hotbar.1 stack67:set_stack_67
execute as @a run item modify entity @s hotbar.2 stack67:set_stack_67
execute as @a run item modify entity @s hotbar.3 stack67:set_stack_67
execute as @a run item modify entity @s hotbar.4 stack67:set_stack_67
execute as @a run item modify entity @s hotbar.5 stack67:set_stack_67
execute as @a run item modify entity @s hotbar.6 stack67:set_stack_67
execute as @a run item modify entity @s hotbar.7 stack67:set_stack_67
execute as @a run item modify entity @s hotbar.8 stack67:set_stack_67

execute as @a run item modify entity @s inventory.9 stack67:set_stack_67
execute as @a run item modify entity @s inventory.10 stack67:set_stack_67
execute as @a run item modify entity @s inventory.11 stack67:set_stack_67
execute as @a run item modify entity @s inventory.12 stack67:set_stack_67
execute as @a run item modify entity @s inventory.13 stack67:set_stack_67
execute as @a run item modify entity @s inventory.14 stack67:set_stack_67
execute as @a run item modify entity @s inventory.15 stack67:set_stack_67
execute as @a run item modify entity @s inventory.16 stack67:set_stack_67
execute as @a run item modify entity @s inventory.17 stack67:set_stack_67
execute as @a run item modify entity @s inventory.18 stack67:set_stack_67
execute as @a run item modify entity @s inventory.19 stack67:set_stack_67
execute as @a run item modify entity @s inventory.20 stack67:set_stack_67
execute as @a run item modify entity @s inventory.21 stack67:set_stack_67
execute as @a run item modify entity @s inventory.22 stack67:set_stack_67
execute as @a run item modify entity @s inventory.23 stack67:set_stack_67
execute as @a run item modify entity @s inventory.24 stack67:set_stack_67
execute as @a run item modify entity @s inventory.25 stack67:set_stack_67
execute as @a run item modify entity @s inventory.26 stack67:set_stack_67
execute as @a run item modify entity @s inventory.27 stack67:set_stack_67
execute as @a run item modify entity @s inventory.28 stack67:set_stack_67
execute as @a run item modify entity @s inventory.29 stack67:set_stack_67
execute as @a run item modify entity @s inventory.30 stack67:set_stack_67
execute as @a run item modify entity @s inventory.31 stack67:set_stack_67
execute as @a run item modify entity @s inventory.32 stack67:set_stack_67
execute as @a run item modify entity @s inventory.33 stack67:set_stack_67
execute as @a run item modify entity @s inventory.34 stack67:set_stack_67
execute as @a run item modify entity @s inventory.35 stack67:set_stack_67

execute as @a run item modify entity @s armor.head stack67:set_stack_67
execute as @a run item modify entity @s armor.chest stack67:set_stack_67
execute as @a run item modify entity @s armor.legs stack67:set_stack_67
execute as @a run item modify entity @s armor.feet stack67:set_stack_67
execute as @a run item modify entity @s weapon.offhand stack67:set_stack_67

tellraw @a {"text":"[Stack67] Инвентарь обработан","color":"green"}

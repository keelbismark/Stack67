# ──────────────────────────────────────────────────────────────────────
# Функция periodic.mcfunction — выполняется каждые 5 секунд
# ──────────────────────────────────────────────────────────────────────
#
# Обходит все слоты инвентаря каждого онлайн-игрока и применяет
# item_modifier, который устанавливает max_stack_size=67.
#
# Запускается через schedule из load.mcfunction и перезапускает
# сама себя (рекурсивный schedule), образуя цикл.
#
# ПРОИЗВОДИТЕЛЬНОСТЬ:
#   41 команда item modify на игрока каждые 5 секунд.
#   Для 10 игроков = 410 команд / 5 сек — нагрузка минимальна.
#   Для 100 игроков = 4100 команд / 5 сек — может быть заметно.
#   Увеличьте интервал в load.mcfunction, если нужно (200t = 10 сек).

# ── Хотбар (слоты 0–8) ──────────────────────────────────────────────
execute as @a run item modify entity @s hotbar.0 stack67:set_stack_67
execute as @a run item modify entity @s hotbar.1 stack67:set_stack_67
execute as @a run item modify entity @s hotbar.2 stack67:set_stack_67
execute as @a run item modify entity @s hotbar.3 stack67:set_stack_67
execute as @a run item modify entity @s hotbar.4 stack67:set_stack_67
execute as @a run item modify entity @s hotbar.5 stack67:set_stack_67
execute as @a run item modify entity @s hotbar.6 stack67:set_stack_67
execute as @a run item modify entity @s hotbar.7 stack67:set_stack_67
execute as @a run item modify entity @s hotbar.8 stack67:set_stack_67

# ── Основной инвентарь (слоты 9–35) ─────────────────────────────────
execute as @a run item modify entity @s inventory.9 stack67:set_stack_67
execute as @a run item modify entity @s inventory.10 stack67:set_stack_67
execute as @a run item modify entity @s inventory.11 stack67:set_stack_67
execute as @a run item modify entity @s inventory.12 stack67:set_stack_67
execute as @a run item modify entity @s inventory.13 stack67:set_stack_67
execute as @a run item modify entity @s inventory.14 stack67:set_stack_67
execute as @a run item modify entity @s inventory.15 stack67:set_stack_67
execute as @a run item modify entity @s inventory.16 stack67:set_stack_67
execute as @a run item modify entity @s inventory.17 stack67:set_stack_67
execute as @a run item modify entity @s inventory.18 stack67:set_stack_67
execute as @a run item modify entity @s inventory.19 stack67:set_stack_67
execute as @a run item modify entity @s inventory.20 stack67:set_stack_67
execute as @a run item modify entity @s inventory.21 stack67:set_stack_67
execute as @a run item modify entity @s inventory.22 stack67:set_stack_67
execute as @a run item modify entity @s inventory.23 stack67:set_stack_67
execute as @a run item modify entity @s inventory.24 stack67:set_stack_67
execute as @a run item modify entity @s inventory.25 stack67:set_stack_67
execute as @a run item modify entity @s inventory.26 stack67:set_stack_67
execute as @a run item modify entity @s inventory.27 stack67:set_stack_67
execute as @a run item modify entity @s inventory.28 stack67:set_stack_67
execute as @a run item modify entity @s inventory.29 stack67:set_stack_67
execute as @a run item modify entity @s inventory.30 stack67:set_stack_67
execute as @a run item modify entity @s inventory.31 stack67:set_stack_67
execute as @a run item modify entity @s inventory.32 stack67:set_stack_67
execute as @a run item modify entity @s inventory.33 stack67:set_stack_67
execute as @a run item modify entity @s inventory.34 stack67:set_stack_67
execute as @a run item modify entity @s inventory.35 stack67:set_stack_67

# ── Броня и левая рука ──────────────────────────────────────────────
execute as @a run item modify entity @s armor.head stack67:set_stack_67
execute as @a run item modify entity @s armor.chest stack67:set_stack_67
execute as @a run item modify entity @s armor.legs stack67:set_stack_67
execute as @a run item modify entity @s armor.feet stack67:set_stack_67
execute as @a run item modify entity @s weapon.offhand stack67:set_stack_67

# ── Эндер-сундук (слоты container.0 – container.26) ─────────────────
# Раскомментируйте, если хотите обрабатывать эндер-сундук:
# execute as @a run item modify entity @s enderchest.0 stack67:set_stack_67
# execute as @a run item modify entity @s enderchest.1 stack67:set_stack_67
# ... (и т.д. до enderchest.26)

# ── Перезапускаем себя через 5 секунд ──────────────────────────────
schedule function stack67:periodic 100t

# Stack67 — мод для Minecraft: максимальный стак 67 (и любое другое значение)

> **Minecraft:** 1.21.1 · **Платформы:** Fabric, NeoForge, Datapack · **Java:** 21+

---

## Содержание

1. [Что делает мод](#-что-делает-мод)
2. [Три варианта реализации](#-три-варианта-реализации)
3. [Архитектура мода](#-архитектура-мода)
4. [Требования](#-требования)
5. [Структура проекта](#-структура-проекта)
6. [Пошаговая инструкция: Fabric](#-пошаговая-инструкция-fabric)
7. [Пошаговая инструкция: NeoForge](#-пошаговая-инструкция-neoforge)
8. [Пошаговая инструкция: Datapack](#-пошаговая-инструкция-datapack)
9. [Конфигурация](#-конфигурация)
10. [Ключевые файлы — подробный разбор](#-ключевые-файлы--подробный-разбор)
11. [Известные ограничения](#-известные-ограничения)
12. [Сравнение подходов](#-сравнение-подходов)
13. [Как расширить мод](#-как-расширить-мод)
14. [Troubleshooting](#-troubleshooting)
15. [FAQ](#-faq)
16. [Полезные ссылки](#-полезные-ссылки)

---

## 📋 Что делает мод

Мод **Stack67** изменяет максимальный размер стака обычных предметов с **64** на **настраиваемое значение** (по умолчанию 67). Это работает для всех предметов, у которых ванильный `maxStackSize` равен порогу (по умолчанию 64 — блоки, ресурсы, еда и т.д.). Предметы с нестандартным размером стака (1 — инструменты/броня, 16 — жемчуг Края/снежки) **не затрагиваются**, если вы не измените порог в конфиге.

### Ключевые особенности

- **Настраиваемый размер стака** — меняйте через `config/stack67.json` без перекомпиляции
- **Три слоя перехвата** — Item (тип), ItemStack (экземпляр), Slot (контейнер)
- **Два модлоадера** — полная поддержка Fabric и NeoForge
- **Datapack-альтернатива** — для тех, кто не хочет ставить модлоадер
- **Подробные комментарии** — каждая строка кода пояснена на русском

---

## 🔀 Три варианта реализации

| Аспект | Fabric Mixin | NeoForge Mixin | Datapack |
|--------|-------------|----------------|----------|
| **Глобальность** | Полная — меняет дефолт для всех предметов | Полная — меняет дефолт для всех предметов | Частичная — только инвентарь игроков |
| **Контейнеры** | Да (SlotMixin) | Да (SlotMixin) | Нет |
| **Конфигурация** | config/stack67.json | config/stack67.json | Только редактирование .mcfunction |
| **Новые предметы** | Автоматически 67 | Автоматически 67 | Только после periodic-обработки |
| **Модлоадер** | Fabric Loader | NeoForge | Не нужен |
| **Сложность установки** | Средняя | Средняя | Простой |
| **Совместимость** | Любые Fabric-моды | Любые NeoForge-моды | Ванильный сервер |
| **Риск багов** | Средний | Средний | Низкий (но ограниченный) |

---

## 🏗 Архитектура мода

```
┌──────────────────────────────────────────────────────────────────┐
│                     ИГРОВОЙ ЦИКЛ MINECRAFT                       │
│                                                                  │
│   Создание предмета          Загрузка мира        Открытие       │
│        │                         │               контейнера      │
│        ▼                         ▼                   │          │
│   Item.getMaxStackSize   ItemStack.getMaxStackSize   │          │
│        │                         │                   ▼          │
│   ┌────┴────┐              ┌────┴────┐      Slot.getMaxStackSize│
│   │ItemMixin│              │ItemStack│         │                │
│   │  64→67  │              │ Mixin   │    ┌────┴────┐           │
│   └────┬────┘              │ 64→67   │    │SlotMixin│           │
│        │                   └────┬────┘    │ лимит→67│           │
│        └──────────┬──────────────┘         └────┬────┘           │
│                   ▼                             │               │
│          ┌──────────────┐                       │               │
│          │ Stack67Config│◄──────────────────────┘               │
│          │(stack67.json)│  Все три Mixin'а читают                │
│          └──────────────┘  настройки из конфига                  │
│                                                                  │
│   config/stack67.json:                                           │
│   {                                                              │
│     "targetStackSize": 67,     ← на что заменять                │
│     "replaceThreshold": 64,    ← какие стаки заменять           │
│     "enableLogging": false     ← отладочный лог (спамно!)       │
│   }                                                              │
└──────────────────────────────────────────────────────────────────┘
```

### Почему три Mixin'а, а не один

| Mixin | Класс | Метод | Когда срабатывает | Почему нужен |
|-------|-------|-------|-------------------|--------------|
| **ItemMixin** | `Item` | `getMaxStackSize()` | При создании нового предмета, крафте, /give | Меняет «дефолтный» размер стака для **типа** предмета |
| **ItemStackMixin** | `ItemStack` | `getMaxStackSize()` | При загрузке мира, чтении из NBT, любом обращении к конкретному стеку | В 1.20.5+ размер хранится как DataComponent внутри ItemStack; ItemMixin не покрывает существующие стеки |
| **SlotMixin** | `Slot` | `getMaxStackSize(ItemStack)` | При помещении предмета в контейнер (сундук, печка, воронка) | Даже если предмет допускает 67, `inventory.getMaxCountPerStack()` обрезает до 64; SlotMixin снимает это ограничение |

---

## 🛠 Требования

### Для Fabric-мода

| Компонент | Версия | Где скачать |
|-----------|--------|-------------|
| **JDK** | 21+ | [Adoptium](https://adoptium.net/) |
| **IDE** | IntelliJ IDEA 2024+ | [JetBrains](https://www.jetbrains.com/idea/download/) |
| **Minecraft** | 1.21.1 | — |
| **Fabric Loader** | 0.16.14+ | [fabricmc.net/use](https://fabricmc.net/use/) |
| **Fabric API** | 0.115.0+ | [Modrinth](https://modrinth.com/mod/fabric-api) |
| **Gradle** | 8.10+ (входит в wrapper) | — |

### Для NeoForge-мода

| Компонент | Версия | Где скачать |
|-----------|--------|-------------|
| **JDK** | 21+ | [Adoptium](https://adoptium.net/) |
| **IDE** | IntelliJ IDEA 2024+ | [JetBrains](https://www.jetbrains.com/idea/download/) |
| **Minecraft** | 1.21.1 | — |
| **NeoForge** | 21.1.127+ | [neoforged.net](https://neoforged.net/) |
| **Gradle** | 8.10+ (входит в wrapper) | — |

### Для Datapack

| Компонент | Версия |
|-----------|--------|
| **Minecraft** | 1.20.5+ (с компонентами предметов) |
| **Сервер/клиент** | Любой (модлоадер не нужен) |

---

## 📦 Структура проекта

### Fabric-мод

```
stack67-fabric/
├── build.gradle                              ← Скрипт сборки (fabric-loom, зависимости)
├── settings.gradle                           ← Репозиторий Fabric Maven
├── gradle.properties                         ← Версии MC/Fabric/мода
├── gradle/wrapper/gradle-wrapper.properties  ← Версия Gradle
├── .gitignore                                ← Исключения для Git
├── LICENSE                                   ← MIT
│
└── src/main/
    ├── java/com/example/stack67/
    │   ├── Stack67Mod.java                   ← Точка входа, загрузка конфига
    │   ├── config/
    │   │   └── Stack67Config.java            ← Конфигурация (JSON-файл)
    │   └── mixin/
    │       ├── ItemMixin.java                ← Item.getMaxStackSize() → 67
    │       ├── ItemStackMixin.java           ← ItemStack.getMaxStackSize() → 67
    │       └── SlotMixin.java                ← Slot.getMaxStackSize() → 67
    │
    └── resources/
        ├── fabric.mod.json                   ← Метаданные мода
        ├── stack67.mixins.json               ← Конфигурация Mixin
        └── pack.mcmeta                       ← Формат ресурсов
```

### NeoForge-мод

```
stack67-neoforge/
├── build.gradle                              ← Скрипт сборки (neoforge-moddev)
├── settings.gradle                           ← Репозиторий NeoForge Maven
├── gradle.properties                         ← Версии MC/NeoForge/мода
├── .gitignore
├── LICENSE
│
└── src/main/
    ├── java/com/example/stack67/
    │   ├── Stack67NeoForge.java              ← Точка входа (@Mod)
    │   ├── config/
    │   │   └── Stack67Config.java            ← Конфигурация (FMLPaths)
    │   └── mixin/
    │       ├── ItemMixin.java                ← Item.getMaxStackSize() (Mojang mappings)
    │       ├── ItemStackMixin.java           ← ItemStack.getMaxStackSize() (Mojang mappings)
    │       └── SlotMixin.java                ← Slot.getMaxStackSize() (Mojang mappings)
    │
    └── resources/
        ├── META-INF/
        │   ├── neoforge.mods.toml            ← Метаданные мода (NeoForge)
        │   └── accesstransformer.cfg         ← Access Transformer (шаблон)
        └── stack67.mixins.json               ← Конфигурация Mixin
```

### Datapack

```
stack67-datapack/
├── pack.mcmeta                               ← Метаданные (pack_format=48)
└── data/
    ├── minecraft/tags/function/
    │   ├── load.json                         ← Автозапуск при загрузке мира
    │   └── tick.json                         ← (альтернатива: каждый тик)
    └── stack67/
        ├── advancements/
        │   └── apply_stack_67.json           ← Триггер при первом входе
        ├── item_modifiers/
        │   └── set_stack_67.json             ← Модификатор: max_stack_size=67
        └── functions/
            ├── load.mcfunction               ← Инициализация + schedule
            ├── periodic.mcfunction           ← Обработка инвентаря каждые 5 сек
            └── apply_stack_67.mcfunction     ← Ручной запуск (/function)
```

---

## 🚀 Пошаговая инструкция: Fabric

### Шаг 1: Установить JDK 21

```bash
# Linux (Ubuntu/Debian)
sudo apt install openjdk-21-jdk

# macOS (Homebrew)
brew install openjdk@21

# Windows — скачайте установщик с https://adoptium.net/
```

Проверка:
```bash
java -version
# openjdk version "21.x.x"
```

### Шаг 2: Создать проект

**Вариант А: Клонировать шаблон Fabric**
```bash
git clone https://github.com/nicholasgasior/fabric-example-mod.git stack67
cd stack67
# Замените файлы на файлы из stack67-fabric/
```

**Вариант Б: Скопировать готовый проект**
```bash
# Просто скопируйте директорию stack67-fabric/ целиком
cp -r stack67-fabric/ ~/IdeaProjects/stack67
```

### Шаг 3: Настроить gradle.properties

Откройте `gradle.properties` и убедитесь, что версии актуальны (проверяйте на [fabricmc.net/develop](https://fabricmc.net/develop/)):

```properties
minecraft_version=1.21.1
yarn_mappings=1.21.1+build.3
loader_version=0.16.14
fabric_version=0.115.0+1.21.1
mod_version=1.1.0
```

### Шаг 4: Открыть в IntelliJ IDEA

1. **File → Open** → выберите папку проекта
2. Дождитесь завершения импорта Gradle (5–15 минут при первом запуске)
3. Если предложили включить аннотации — согласитесь

### Шаг 5: Собрать

```bash
./gradlew build
# Результат: build/libs/stack67-1.1.0.jar
```

### Шаг 6: Протестировать

```bash
# Запуск клиента (с модом, из IDE):
./gradlew runClient

# Запуск сервера:
./gradlew runServer
```

### Шаг 7: Установить в Minecraft

1. Установите [Fabric Loader](https://fabricmc.net/use/)
2. Скопируйте `build/libs/stack67-1.1.0.jar` → `.minecraft/mods/`
3. Скопируйте [Fabric API](https://modrinth.com/mod/fabric-api) → `.minecraft/mods/`
4. Запустите Minecraft с профилем Fabric
5. Проверьте в логе: `Stack67 загружен успешно`
6. Поднимите 67 камней в один стак — работает!

---

## 🚀 Пошаговая инструкция: NeoForge

### Шаг 1–2: Те же, что и для Fabric

### Шаг 3: Создать проект

```bash
# Скопируйте директорию stack67-neoforge/ целиком
cp -r stack67-neoforge/ ~/IdeaProjects/stack67-neoforge
```

### Шаг 4: Настроить gradle.properties

```properties
minecraft_version=1.21.1
neoforge_version=21.1.127
mod_version=1.1.0
```

### Шаг 5–7: Те же, что и для Fabric

При сборке:
```bash
./gradlew build
# Результат: build/libs/stack67-neoforge-1.1.0.jar
```

Установите в `.minecraft/mods/` вместе с NeoForge.

---

## 🚀 Пошаговая инструкция: Datapack

### Шаг 1: Упаковать

```bash
cd stack67-datapack
zip -r stack67-datapack.zip ./*
```

### Шаг 2: Установить

| Режим | Путь |
|-------|------|
| Одиночная игра | `.minecraft/saves/<Мир>/datapacks/stack67-datapack.zip` |
| Сервер | `world/datapacks/stack67-datapack.zip` |

### Шаг 3: Активировать

1. Зайдите в мир (или `/reload`)
2. При загрузке автоматически запустится `load.mcfunction`
3. Начнётся periodic-обработка инвентаря каждые 5 секунд
4. Вы увидите сообщение: `[Stack67] Датапак загружен`

### Ручной запуск

```
/function stack67:apply_stack_67
```

---

## ⚙ Конфигурация

### config/stack67.json (Fabric и NeoForge)

Файл автоматически создаётся при первом запуске мода в папке `config/`.

```json
{
  "targetStackSize": 67,
  "replaceThreshold": 64,
  "enableLogging": false
}
```

| Параметр | Тип | По умолчанию | Описание |
|----------|-----|-------------|----------|
| `targetStackSize` | int | 67 | На какое значение заменять. Безопасный диапазон: 1–99. Значения >99 вызывают серьёзные баги рендеринга. |
| `replaceThreshold` | int | 64 | Какие стаки заменять. 64 = только обычные предметы. 16 = также жемчуг Края, снежки и т.д. **Не ставьте 1** — сломаете инструменты и броню! |
| `enableLogging` | bool | false | Выводить отладочные сообщения в лог. **ОСТОРОЖНО**: логируется каждый вызов `getMaxStackSize()` — это тысячи строк в секунду! Используйте только для отладки. |

### Примеры конфигурации

**Стак до 99 для обычных предметов:**
```json
{ "targetStackSize": 99, "replaceThreshold": 64, "enableLogging": false }
```

**Стак до 67 также для жемчуга/снежков (было 16):**
```json
{ "targetStackSize": 67, "replaceThreshold": 16, "enableLogging": false }
```

**Отладка (каждый вызов в лог):**
```json
{ "targetStackSize": 67, "replaceThreshold": 64, "enableLogging": true }
```

---

## 🔑 Ключевые файлы — подробный разбор

### Stack67Config.java (Fabric/NeoForge)

Система конфигурации без внешних зависимостей (только Gson, входящий в Minecraft). Читает `config/stack67.json` при первом обращении (`get()`), кэширует результат. При ошибке парсинга — использует значения по умолчанию вместо краша игры. Автоматически создаёт файл-шаблон при первом запуске.

Ключевые решения:
- **Singleton** — конфиг загружается один раз, повторные вызовы `get()` возвращают кэш
- **Fail-safe** — любая ошибка чтения → дефолтные значения, не краш
- **Null-safe** — если JSON неполный (отсутствуют поля), подставляются дефолты
- **Auto-save** — при первой загрузке файл всегда пересохраняется, чтобы пользователь увидел все доступные параметры

### ItemMixin.java

```java
@Mixin(Item.class)                              // Подмешиваемся к Item
public abstract class ItemMixin {
    @Inject(method = "getMaxStackSize",          // Перехватываем этот метод
            at = @At("RETURN"),                  // В момент возврата значения
            cancellable = true)                  // С правом замены результата
    private void stack67$modifyMaxStack(CallbackInfoReturnable<Integer> cir) {
        Stack67Config config = Stack67Config.get();
        int original = cir.getReturnValue();     // Что вернул ванильный метод
        if (original == config.replaceThreshold) { // Если это «обычный» стак
            cir.setReturnValue(config.targetStackSize); // Заменяем
        }
    }
}
```

**Почему `@At("RETURN")`**: нам нужно узнать, что вернул ванильный метод, прежде чем решать, заменять ли. `@At("HEAD")` не дал бы доступа к возвращаемому значению.

**Почему `cancellable = true`**: без этого параметра `cir.setReturnValue()` выбросит исключение.

**Почему `private`**: Mixin-методы не должны быть частью публичного API класса. `private` гарантирует, что никто не вызовет их извне.

**Именование `stack67$modifyMaxStack`**: префикс `stack67$` предотвращает коллизии с другими модами, которые тоже могут внедрять методы в Item. Это стандартная конвенция Fabric/NeoForge.

### ItemStackMixin.java

Аналогичен `ItemMixin`, но для `ItemStack`. В 1.20.5+ размер стака хранится как **DataComponent** внутри `ItemStack`. Когда мир загружается с диска, существующие стеки уже содержат `max_stack_size=64` в компоненте. `ItemMixin` меняет только дефолт для новых предметов, а `ItemStackMixin` перехватывает геттер и для существующих.

### SlotMixin.java

Самый важный из трёх Mixin'ов с практической точки зрения. Без него:

1. Предмет «знает», что его стак = 67 ✓
2. Игрок может держать 67 предметов в инвентаре ✓
3. Но при попытке положить 67 предметов в сундук → влезет только 64 ✗

Причина: `Slot.getMaxStackSize()` возвращает `Math.min(inventory.getMaxCountPerStack(), stack.getMaxStackSize())`. `inventory.getMaxCountPerStack()` для ванильных контейнеров = 64. Поэтому даже при `stack.getMaxStackSize() = 67`, слот обрезает до 64.

`SlotMixin` исправляет это: если `stack.getMaxStackSize()` > `inventory.getMaxCountPerStack()` и при этом равно `targetStackSize` из конфига (т.е. наш мод увеличил стак), то возвращаем значение предмета, игнорируя лимит инвентаря.

### fabric.mod.json (Fabric)

Метаданные мода. Ключевые поля:
- `id`: уникальный идентификатор (должен совпадать с `MOD_ID` в Java)
- `entrypoints.main`: класс с методом `onInitialize()`
- `mixins`: ссылка на `stack67.mixins.json`
- `depends`: ограничения по версиям (Fabric Loader ≥0.16, MC ~1.21.1, Java ≥21)
- `recommends`: ModMenu (опционально, для отображения мода в списке)

### neoforge.mods.toml (NeoForge)

Аналог fabric.mod.json для NeoForge. TOML-формат. Содержит:
- `modId`, `version`, `displayName`, `description`
- Ссылку на Mixin-конфиг (`stack67.mixins.json`)
- Зависимости: `neoforge ≥21.1`, `minecraft [1.21.1, 1.21.2)`

---

## ⚠ Известные ограничения

### Критические

| Проблема | Описание | Статус |
|----------|----------|--------|
| **UI слотов** | Слоты инвентаря рассчитаны на 2-значное число. При 65–67 число может вылезать за границы иконки или обрезаться. | ⚠️ Визуальный баг |
| **Контейнеры** | Воронки и хопперы проверяют лимит при автоперемещении. SlotMixin снимает ограничение, но возможны краевые случаи. | ⚠️ Возможные баги |
| **Рецепты крафта** | Рецепты, которые проверяют размер стака, могут работать некорректно (компакторы, распаковщики из других модов). | ⚠️ Возможные баги |
| **Мультиплеер** | Мод должен быть установлен **на клиенте и сервере одновременно**. Иначе — рассинхронизация и краши. | 🔴 Обязательно |
| **Мир между версиями** | При удалении мода предметы в стеках >64 остаются, но новые стаки снова ограничены 64. Безопасно, но может запутать. | 💡 Безопасно |

### Некритические

| Проблема | Описание | Статус |
|----------|----------|--------|
| **Совместимость** | Моды, которые тоже меняют `getMaxStackSize()` через Mixin, могут конфликтовать. | 💡 Проверяйте |
| **Datapack-лимит** | Datapack НЕ обрабатывает контейнеры, крафт, подбор и автокрафт. | 💡 Только для теста |
| **NBT** | Компонент `max_stack_size` в NBT по-прежнему хранит 64. Это безопасно (при удалении мода — возврат к норме), но другие моды, читающие DataComponent напрямую, увидят 64. | 💡 Редкий случай |

### ⚠️ Предупреждение

```
┌──────────────────────────────────────────────────────────────┐
│  ВНИМАНИЕ: Стак размером >64 НЕ является стандартным для     │
│  Minecraft. Движок игры, GUI и большинство модов             │
│  предполагают, что maxStackSize ≤ 64. Использование этого    │
│  мода может привести к:                                       │
│    • Визуальным багам в инвентаре и контейнерах              │
│    • Дюпам предметов при автосортировке                       │
│    • Некорректной работе рецептов                             │
│    • Конфликтам с другими модами                              │
│                                                               │
│  Автор мода НЕ несёт ответственности за потерю предметов,    │
│  повреждение миров или другие проблемы.                       │
│  Рекомендуется: РЕЗЕРВНОЕ КОПИРОВАНИЕ МИРА ПЕРЕД ЗАПУСКОМ!   │
└──────────────────────────────────────────────────────────────┘
```

---

## 📊 Сравнение подходов

### Fabric vs NeoForge — что выбрать?

| Критерий | Fabric | NeoForge |
|----------|--------|----------|
| **Скорость запуска IDE** | Быстрее (простой Gradle) | Медленнее (ModDev загружает больше) |
| **Mappings** | Yarn (читаемые имена) | Mojang (официальные имена) |
| **Размер сообщества** | Очень большое | Большое |
| **Количество модов** | Больше (модринт) | Много (курсфорж) |
| **Обновления** | Быстрее | Медленнее |
| **Документация** | Хорошая | Отличная |

### Datapack — когда использовать?

- ✅ Ванильный сервер без модлоадера
- ✅ Быстрый тест идеи
- ✅ Совместимость со ВСЕМИ модлоадерами
- ❌ Не покрывает контейнеры, крафт, новые предметы
- ❌ Периодическая обработка (задержка до 5 сек)

---

## 🔧 Как расширить мод

### Изменить целевой размер стака

В `config/stack67.json`:
```json
{ "targetStackSize": 128, "replaceThreshold": 64, "enableLogging": false }
```

Перезапустите Minecraft — новые значения применятся автоматически.

### Применить только к конкретным предметам

Замените пороговую проверку на проверку типа предмета:

```java
// В ItemMixin.java — только для алмазов и железной руды
@Inject(method = "getMaxStackSize", at = @At("RETURN"), cancellable = true)
private void stack67$modifyMaxStack(CallbackInfoReturnable<Integer> cir) {
    Item self = (Item)(Object)this;  // Получаем ссылку на Item
    if (self == Items.DIAMOND || self == Items.IRON_ORE) {
        cir.setReturnValue(67);
    }
}
```

### Добавить конфигурацию для конкретных предметов

Расширьте `Stack67Config`:
```java
public Map<String, Integer> itemOverrides = Map.of(
    "minecraft:diamond", 99,
    "minecraft:iron_ore", 100
);
```

И в ItemMixin:
```java
@Override
private void stack67$modifyMaxStack(CallbackInfoReturnable<Integer> cir) {
    Item self = (Item)(Object)this;
    Identifier id = Registries.ITEM.getId(self);
    Stack67Config config = Stack67Config.get();

    // Проверяем индивидуальные переопределения
    if (config.itemOverrides.containsKey(id.toString())) {
        cir.setReturnValue(config.itemOverrides.get(id.toString()));
        return;
    }

    // Общее правило
    if (cir.getReturnValue() == config.replaceThreshold) {
        cir.setReturnValue(config.targetStackSize);
    }
}
```

### Добавить команду /stack67 reload

Создайте класс команды, регистрируйте через `CommandRegistrationCallback`:
```java
CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
    dispatcher.register(CommandManager.literal("stack67")
        .then(CommandManager.literal("reload").executes(ctx -> {
            Stack67Config.reload();
            ctx.getSource().sendFeedback(() -> Text.literal("Конфиг Stack67 перезагружен"), true);
            return 1;
        }))
    );
});
```

---

## 🔧 Troubleshooting

### Мод не загружается

| Симптом | Причина | Решение |
|---------|---------|---------|
| `java.lang.UnsupportedClassVersionError` | Несовместимая версия Java | Установите JDK 21+ |
| `Mixin apply error` | Несовпадение версий MC/mappings | Обновите `gradle.properties` |
| `Could not resolve` | Нет доступа к Maven | Проверьте интернет, repositories в build.gradle |
| Мод не виден в списке | Не та папка mods | Убедитесь: `.minecraft/mods/`, а не `.minecraft/versions/.../mods/` |

### Предметы по-прежнему стакаются до 64

1. Проверьте лог: есть ли `Stack67 загружен успешно`
2. Проверьте `config/stack67.json` — правильные ли значения
3. Попробуйте `enableLogging: true` — если ItemMixin НЕ вызывается, значит Mixin не подключился
4. Убедитесь, что `stack67.mixins.json` включён в JAR (распакуйте и проверьте)

### Краши при открытии контейнера

1. SlotMixin может конфликтовать с модами на контейнеры
2. Попробуйте убрать SlotMixin из `stack67.mixins.json` — контейнеры будут ограничены 64, но краши прекратятся
3. Сообщите о баге на GitHub с логом краша

### Datapack не работает

1. Проверьте `pack_format`: 48 для MC 1.21.1, 34 для 1.21, 18 для 1.20.5
2. Убедитесь, что datapack включён: `/datapack list` → должен быть `✅ stack67`
3. Выполните `/function stack67:apply_stack_67` вручную — если ошибка, проблема в синтаксисе

### Ошибка Gradle при сборке

```bash
# Очистить кэш и пересобрать
./gradlew clean build --refresh-dependencies

# Если не помогло — удалить .gradle/ и build/
rm -rf .gradle/ build/
./gradlew build
```

---

## ❓ FAQ

**Q: Можно ли поставить стак 999?**
A: Технически — да (измените `targetStackSize`). Практически — GUI полностью сломается, возможны краши. Безопасный максимум: 99.

**Q: Будет ли мод работать на сервере?**
A: Да, но мод должен быть установлен **и на клиенте, и на сервере**. Иначе — рассинхронизация.

**Q: Что произойдёт при удалении мода?**
A: Предметы в стеках >64 останутся, но новые стаки будут ограничены 64. Если вы переложите стек >64, «лишние» предметы выпадут. Мир не повредится.

**Q: Совместим ли мод с Sodium / Lithium?**
A: Да, они не затрагивают `getMaxStackSize()`. Но другие моды, меняющие стак (например, StackRefill), могут конфликтовать.

**Q: Работает ли с модами на новые предметы?**
A: Да! Если мод добавляет предметы со `maxStackSize = 64`, наш Mixin автоматически увеличит их до 67.

**Q: Почему 67, а не 99 или 128?**
A: 67 — пример нестандартного значения. Вы можете поставить любое через конфиг. 67 выбрано как минимальное отклонение от 64 для демонстрации.

**Q: Datapack обрабатывает эндер-сундук?**
A: Нет, по умолчанию. Раскомментируйте строки в `periodic.mcfunction` для эндер-сундука.

---

## 📚 Полезные ссылки

- [Fabric Wiki](https://fabricmc.net/wiki/) — документация Fabric
- [Fabric Example Mod](https://github.com/nicholasgasior/fabric-example-mod) — шаблон проекта
- [Mixin Wiki](https://github.com/SpongePowered/Mixins/wiki) — документация по Mixin
- [Yarn Mappings](https://maven.fabricmc.net/) — поиск имён классов/методов
- [NeoForge Documentation](https://docs.neoforged.net/) — документация NeoForge
- [Minecraft Wiki: Data Component](https://minecraft.wiki/w/Data_component_format) — формат компонентов (1.20.5+)
- [Minecraft Wiki: Item Modifier](https://minecraft.wiki/w/Item_modifier) — формат модификаторов предметов

---

## 📄 Лицензия

MIT — используйте свободно, но помните об ограничениях, описанных выше.

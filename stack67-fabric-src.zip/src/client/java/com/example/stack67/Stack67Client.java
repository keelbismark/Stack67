package com.example.stack67;

import com.example.stack67.config.Stack67Config;
import net.fabricmc.api.ClientModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * ──────────────────────────────────────────────────────────────────────
 * Stack67Client — клиентская точка входа мода «Stack67»
 * ──────────────────────────────────────────────────────────────────────
 *
 * Этот класс реализует ClientModInitializer — интерфейс Fabric для
 * клиентской инициализации. Он вызывается только на стороне клиента.
 *
 * Зачем нужен отдельный клиентский инициализатор:
 *   1. DrawContextMixin (рендер счётчика >64) работает ТОЛЬКО на клиенте
 *   2. Нам нужно логировать, что клиентский рендеринг включён
 *   3. В будущем здесь можно добавить настройку HUD / опций рендеринга
 *
 * Без этого класса Fabric не загрузит стеклянный (client) Mixin-набор,
 * и счётчик >64 будет отображаться некорректно.
 * ──────────────────────────────────────────────────────────────────────
 */
public class Stack67Client implements ClientModInitializer {

    /** Клиентский логгер — отдельный от серверного для удобства фильтрации */
    private static final Logger CLIENT_LOGGER = LoggerFactory.getLogger("stack67-client");

    /**
     * Вызывается Fabric на этапе инициализации клиента.
     * Здесь мы подтверждаем, что клиентские Mixin'ы загружены
     * и рендеринг счётчика стаков >64 активен.
     */
    @Override
    public void onInitializeClient() {
        Stack67Config config = Stack67Config.get();

        CLIENT_LOGGER.info("╔══════════════════════════════════════════╗");
        CLIENT_LOGGER.info("║  Stack67 Client загружен                ║");
        CLIENT_LOGGER.info("║  Рендеринг стаков >64: ВКЛЮЧЁН          ║");
        CLIENT_LOGGER.info("║  Целевой размер стака: {}               ║", config.targetStackSize);
        CLIENT_LOGGER.info("╚══════════════════════════════════════════╝");

        // Предупреждение о потенциальных проблемах рендеринга
        if (config.targetStackSize > 99) {
            CLIENT_LOGGER.warn("⚠ Stack67 Client: targetStackSize={} > 99 — рендеринг счётчика может быть некорректным!",
                    config.targetStackSize);
        }
    }
}

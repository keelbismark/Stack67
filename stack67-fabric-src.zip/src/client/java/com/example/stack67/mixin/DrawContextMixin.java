package com.example.stack67.mixin;

import com.example.stack67.config.Stack67Config;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * ──────────────────────────────────────────────────────────────────────
 * DrawContextMixin — исправление рендеринга счётчика стаков >64
 * ──────────────────────────────────────────────────────────────────────
 *
 * ПРОБЛЕМА:
 *   Ванильный Minecraft отображает количество предметов в слоте через
 *   DrawContext.drawItemInSlot(). По умолчанию счётчик рендерится
 *   с масштабом, рассчитанным на значения 1–64. Когда количество
 *   превышает 64, текст «67» (или «99») выглядит нормально, но
 *   начиная со 100+ цифры выходят за границы ячейки инвентаря.
 *
 *   Кроме того, ванильный рендерер может вообще не отображать
 *   число корректно, если оно не помещается в стандартный формат.
 *
 * РЕШЕНИЕ:
 *   Мы внедряемся в конец метода drawItemInSlot() (TAIL) и,
 *   если количество > 64, повторно отрисовываем счётчик с
 *   правильным масштабированием:
 *     • 65–99  → масштаб 1.0 (как в ваниле, но гарантированно)
 *     • 100+   → масштаб 0.7 (уменьшенный, чтобы вместить 3+ цифры)
 *
 *   Используем матричные преобразования:
 *     1. push()     — сохраняем текущее состояние матрицы
 *     2. translate() — сдвигаем позицию для центровки текста
 *     3. scale()    — уменьшаем масштаб при необходимости
 *     4. pop()      — восстанавливаем матрицу
 *
 *   Это клиентский Mixin — он НЕ загружается на сервере.
 *
 * ──────────────────────────────────────────────────────────────────────
 */
@Mixin(DrawContext.class)
public abstract class DrawContextMixin {

    /**
     * Ванильный метод отрисовки текста в контексте DrawContext.
     * Нужен для повторного рендера счётчика с правильным масштабом.
     */
    @Shadow
    public abstract void drawText(TextRenderer textRenderer, String text, int x, int y, int color, boolean shadow);

    /**
     * Перехват метода drawItemInSlot на выходе (TAIL).
     *
     * Если количество предметов > 64, повторно рендерим счётчик
     * с корректным масштабированием, чтобы число помещалось
     * в ячейку инвентаря и не перекрывало соседние элементы.
     *
     * @param textRenderer  рендерер текста (шрифты)
     * @param stack         предмет в слоте
     * @param x             координата X ячейки
     * @param y             координата Y ячейки
     * @param countOverride переопределение текста счётчика (может быть null)
     * @param ci            callback информации (не отменяем, только дополняем)
     */
    @Inject(method = "drawItemInSlot(Lnet/minecraft/client/font/TextRenderer;Lnet/minecraft/item/ItemStack;IILjava/lang/String;)V",
            at = @At("TAIL"))
    private void stack67$renderLargeStackCount(TextRenderer textRenderer, ItemStack stack, int x, int y,
                                                String countOverride, CallbackInfo ci) {
        // Проверяем, что стек действительно увеличенный
        int count = stack.getCount();
        if (count <= 64) return;

        // Получаем настройки — убедимся, что мы вообще включены
        Stack67Config config = Stack67Config.get();
        if (count <= config.replaceThreshold) return;

        // Формируем строку счётчика (используем override если есть)
        String countString = countOverride != null ? countOverride : String.valueOf(count);

        // Вычисляем масштаб: для 2-значных чисел — нормальный, для 3+ — уменьшенный
        float scaleFactor;
        if (count <= 99) {
            scaleFactor = 1.0f;
        } else {
            scaleFactor = 0.7f;
        }

        // Вычисляем позицию для центровки текста в ячейке (16x16 пикселей)
        // Ванильный код рисует счётчик в правом нижнем углу ячейки
        int textWidth = textRenderer.getWidth(countString);

        // Базовая позиция: правый нижний угол ячейки
        float baseX = x + 19 - textWidth * scaleFactor;
        float baseY = y + 6 + 3;

        // Применяем матричные преобразования для масштабирования
        // Используем матрицы DrawContext для корректного рендера
        DrawContext self = (DrawContext) (Object) this;
        self.getMatrices().push();

        // Сдвигаем и масштабируем
        self.getMatrices().translate(baseX, baseY, 200.0f); // 200 = Z-уровень поверх предметов
        self.getMatrices().scale(scaleFactor, scaleFactor, 1.0f);

        // Рисуем счётчик с тенью (как в ваниле)
        drawText(textRenderer, countString, 0, 0, 0xFFFFFF, true);

        // Восстанавливаем матрицу
        self.getMatrices().pop();
    }
}

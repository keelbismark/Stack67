package com.example.stack67;

import com.example.stack67.commands.Stack67Commands;
import com.example.stack67.config.Stack67Config;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * ──────────────────────────────────────────────────────────────────────
 * Stack67Mod — главный класс мода «Stack67» для Fabric
 * ──────────────────────────────────────────────────────────────────────
 *
 * Что делает этот мод:
 *   С помощью Mixin перехватывает методы Item#getMaxCount(),
 *   ItemStack#getMaxCount() и Slot#getMaxItemCount(ItemStack)
 *   и заменяет возвращаемое значение 64 → настраиваемое значение
 *   (по умолчанию 67, меняется через config/stack67.json).
 *
 * Архитектура (v1.2.0):
 *   ┌──────────────────────────────────────────────────┐
 *   │  Stack67Mod  (точка входа, загрузка конфига)     │
 *   │       ↓                                           │
 *   │  Stack67Config (config/stack67.json)              │
 *   │       ↓                                           │
 *   │  ItemMixin       → Item.getMaxCount()              │
 *   │  ItemStackMixin  → ItemStack.getMaxCount()         │
 *   │  SlotMixin       → Slot.getMaxItemCount(Item)      │
 *   │  InventoryMixin  → Inventory.getMaxCountPerStack()│
 *   │       ↓                                           │
 *   │  DrawContextMixin → DrawContext.drawItemInSlot()  │
 *   │  (клиентский, рендер счётчика >64)               │
 *   │       ↓                                           │
 *   │  Stack67Commands → /stack67, /stack67 reload,    │
 *   │                    /stack67 status, /stack67 set  │
 *   └──────────────────────────────────────────────────┘
 *
 * Почему ПЯТЬ Mixin'ов + клиентский DrawContextMixin:
 *   ItemMixin      — меняет «дефолтный» размер стака для ТИПА предмета.
 *                    Работает при создании новых предметов.
 *   ItemStackMixin — перехватывает геттер у конкретного ЭКЗЕМПЛЯРА.
 *                    Нужен, т.к. в 1.20.5+ размер стака хранится
 *                    как DataComponent внутри ItemStack.
 *   SlotMixin      — расширяет лимит слота в контейнерах.
 *                    Без него воронки/сундуки будут отвергать
 *                    стак >64, даже если сам предмет его допускает.
 *   InventoryMixin  — перехватывает Inventory.getMaxCountPerStack().
 *                    САМЫЙ ВАЖНЫЙ Mixin: покрывает ВСЕ контейнеры
 *                    на уровне корневого интерфейса (воронки,
 *                    разбрасыватели, сундуки и т.д.).
 *   DrawContextMixin — клиентский: корректный рендер счётчика >64.
 *                    Без него число >64 отображается криво.
 *
 *   Плюс система команд /stack67 для управления модом из игры.
 *
 * Версия: 1.2.0
 *
 * ВНИМАНИЕ: Стак >64 может вызывать баги UI в контейнерах и рецептах.
 *           См. подробности в README → «Известные ограничения».
 * ──────────────────────────────────────────────────────────────────────
 */
public class Stack67Mod {

    /** Уникальный идентификатор мода — должен совпадать с id в fabric.mod.json */
    public static final String MOD_ID = "stack67";

    /** Логгер для вывода сообщений в консоль игры / лог-файлы */
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    /**
     * Точка входа мода.
     * Fabric вызывает этот метод на этапе инициализации (после загрузки
     * всех ресурсов, но до полного запуска игрового цикла).
     *
     * Здесь мы:
     *   1. Загружаем конфигурацию (Stack67Config.get()).
     *   2. Выводим диагностическую информацию в лог.
     *   3. Реальная работа делается в Mixin-классах автоматически.
     */
    public void onInitialize() {
        // Загружаем конфиг — это создаёт файл config/stack67.json,
        // если его ещё нет, и логирует текущие настройки
        Stack67Config config = Stack67Config.get();

        // Регистрируем команды /stack67
        Stack67Commands.register();

        // Диагностика при запуске — помогает понять, что мод работает
        LOGGER.info("╔══════════════════════════════════════════╗");
        LOGGER.info("║  Stack67 v1.2.0 загружен успешно         ║");
        LOGGER.info("║  Целевой размер стака: {}                ║", config.targetStackSize);
        LOGGER.info("║  Порог замены: {}                        ║", config.replaceThreshold);
        LOGGER.info("║  Mixin'ов: 5 серверных + 1 клиентский   ║");
        LOGGER.info("║  Команды: /stack67, reload, status, set  ║");
        LOGGER.info("║  Файл конфигурации: config/stack67.json  ║");
        LOGGER.info("╚══════════════════════════════════════════╝");

        // Предупреждение, если значение потенциально опасное
        if (config.targetStackSize > 99) {
            LOGGER.warn("⚠ Stack67: targetStackSize={} > 99 — возможны серьёзные баги рендеринга!",
                    config.targetStackSize);
        }
        if (config.targetStackSize > 64 && config.replaceThreshold == 64) {
            LOGGER.info("Stack67: предметы со стеком 64 теперь стакаются до {}",
                    config.targetStackSize);
        }
    }
}

package com.example.stack67.commands;

import com.example.stack67.Stack67Mod;
import com.example.stack67.config.Stack67Config;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.text.Text;

/**
 * ──────────────────────────────────────────────────────────────────────
 * Stack67Commands — система команд мода /stack67
 * ──────────────────────────────────────────────────────────────────────
 *
 * Регистрирует команды для управления модом прямо из игры:
 *
 *   /stack67           — показать справку по командам
 *   /stack67 reload    — перезагрузить конфиг из файла (OP 2)
 *   /stack67 status    — показать текущие настройки
 *   /stack67 set <N>   — временно изменить targetStackSize на N (1–99, OP 2)
 *
 * Команды используют Brigadier — стандартный фреймворк команд Minecraft.
 * Требования к правам (OP level) соответствуют принципу наименьших привилегий:
 *   • status и help — доступны всем (информационные)
 *   • reload и set — требуют OP 2 (изменение состояния)
 *
 * ВНИМАНИЕ: команда /stack67 set меняет значение ТОЛЬКО в памяти!
 *   Для постоянного изменения нужно отредактировать config/stack67.json
 *   или выполнить /stack67 reload после изменения файла.
 * ──────────────────────────────────────────────────────────────────────
 */
public class Stack67Commands {

    /**
     * Регистрирует все команды мода через CommandRegistrationCallback.
     * Вызывается из Stack67Mod.onInitialize() при загрузке мода.
     */
    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {

            // Корневой узел /stack67
            dispatcher.register(CommandManager.literal("stack67")

                // ── /stack67 — справка ──────────────────────────────
                .executes(context -> {
                    ServerCommandSource source = context.getSource();
                    // Отправляем список доступных команд
                    source.sendFeedback(() -> Text.literal("§6╔══════════════════════════════════╗"), false);
                    source.sendFeedback(() -> Text.literal("§6║  §eStack67 §6— команды мода      ║"), false);
                    source.sendFeedback(() -> Text.literal("§6╠══════════════════════════════════╣"), false);
                    source.sendFeedback(() -> Text.literal("§6║  §e/stack67 §7— эта справка     ║"), false);
                    source.sendFeedback(() -> Text.literal("§6║  §e/stack67 reload §7— перезагрузить конфиг ║"), false);
                    source.sendFeedback(() -> Text.literal("§6║  §e/stack67 status §7— текущие настройки  ║"), false);
                    source.sendFeedback(() -> Text.literal("§6║  §e/stack67 set <N> §7— изменить размер стака ║"), false);
                    source.sendFeedback(() -> Text.literal("§6╚══════════════════════════════════╝"), false);
                    return 1;
                })

                // ── /stack67 reload — перезагрузка конфига ───────────
                .then(CommandManager.literal("reload")
                    .requires(source -> source.hasPermissionLevel(2)) // Требуется OP 2
                    .executes(context -> {
                        ServerCommandSource source = context.getSource();

                        // Перезагружаем конфигурацию из файла
                        Stack67Config.reload();
                        Stack67Config config = Stack67Config.get();

                        // Подтверждение пользователю
                        source.sendFeedback(() -> Text.literal("§a[Stack67] Конфигурация перезагружена! " +
                                "targetStackSize=" + config.targetStackSize +
                                ", replaceThreshold=" + config.replaceThreshold), true);
                        return 1;
                    })
                )

                // ── /stack67 status — текущие настройки ──────────────
                .then(CommandManager.literal("status")
                    .executes(context -> {
                        ServerCommandSource source = context.getSource();
                        Stack67Config config = Stack67Config.get();

                        // Выводим все настройки мода
                        source.sendFeedback(() -> Text.literal("§6[Stack67] Текущие настройки:"), false);
                        source.sendFeedback(() -> Text.literal("§7  targetStackSize: §e" + config.targetStackSize), false);
                        source.sendFeedback(() -> Text.literal("§7  replaceThreshold: §e" + config.replaceThreshold), false);
                        source.sendFeedback(() -> Text.literal("§7  enableLogging: §e" + config.enableLogging), false);
                        source.sendFeedback(() -> Text.literal("§7  Конфиг-файл: §fconfig/stack67.json"), false);
                        return 1;
                    })
                )

                // ── /stack67 set <int> — временное изменение стака ───
                .then(CommandManager.literal("set")
                    .requires(source -> source.hasPermissionLevel(2)) // Требуется OP 2
                    .then(CommandManager.argument("size", IntegerArgumentType.integer(1, 99))
                        .executes(context -> {
                            ServerCommandSource source = context.getSource();
                            int newSize = IntegerArgumentType.getInteger(context, "size");

                            // Валидация значения
                            if (!Stack67Config.isValidStackSize(newSize)) {
                                source.sendError(Text.literal("§c[Stack67] Недопустимое значение: " + newSize +
                                        ". Допустимый диапазон: 1–99."));
                                return 0;
                            }

                            // Меняем значение В ПАМЯТИ (не сохраняем в файл!)
                            Stack67Config config = Stack67Config.get();
                            int oldSize = config.targetStackSize;
                            config.targetStackSize = newSize;

                            // Подтверждение
                            source.sendFeedback(() -> Text.literal("§a[Stack67] targetStackSize изменён: " +
                                    oldSize + " → " + newSize +
                                    " §7(временно, до перезапуска)"), true);

                            // Предупреждение о больших значениях
                            if (newSize > 99) {
                                source.sendFeedback(() -> Text.literal("§c[Stack67] ВНИМАНИЕ: значение >99 может вызывать баги рендеринга!"), false);
                            }

                            return 1;
                        })
                    )
                )
            );

            // Логируем успешную регистрацию команд
            Stack67Mod.LOGGER.info("Команды /stack67 зарегистрированы");
        });
    }
}

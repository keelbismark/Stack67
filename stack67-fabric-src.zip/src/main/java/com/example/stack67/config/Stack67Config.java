package com.example.stack67.config;

import com.example.stack67.Stack67Mod;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * ──────────────────────────────────────────────────────────────────────
 * Stack67Config — система конфигурации мода
 * ──────────────────────────────────────────────────────────────────────
 *
 * Позволяет пользователю менять целевой размер стака БЕЗ перекомпиляции.
 * Конфиг хранится в файле config/stack67.json рядом с папкой игры.
 *
 * Формат файла:
 * {
 *   "targetStackSize": 67,
 *   "replaceThreshold": 64,
 *   "enableLogging": false
 * }
 *
 * Поля:
 *   targetStackSize  — на какое значение заменять (по умолчанию 67)
 *   replaceThreshold — какие стаки заменять (по умолчанию 64, т.е.
 *                      только «обычные» предметы; можно поставить 16,
 *                      чтобы также менять стаки снежков/жемчуга)
 *   enableLogging    — выводить ли отладочные сообщения в лог
 *                      (каждый вызов getMaxCount — очень спамно!)
 *
 * При ошибке чтения/парсинга — используется конфиг по умолчанию,
 * а не краш игры. Это важно для стабильности.
 * ──────────────────────────────────────────────────────────────────────
 */
public class Stack67Config {

    /** Целевой размер стака (вместо 64) */
    public int targetStackSize = 67;

    /** Порог замены: заменяем стаки, у которых maxCount == replaceThreshold */
    public int replaceThreshold = 64;

    /** Включить подробное логирование (ОСТОРОЖНО: очень спамно) */
    public boolean enableLogging = false;

    // ── Внутренние поля ──────────────────────────────────────────────
    private static final Gson GSON = new GsonBuilder()
            .setPrettyPrinting()    // Красивое форматирование JSON
            .create();

    private static final Path CONFIG_PATH = FabricLoader.getInstance()
            .getConfigDir()
            .resolve("stack67.json");

    // Единственный экземпляр (singleton) — загружается один раз при старте
    private static Stack67Config instance;

    // ── Публичный доступ ─────────────────────────────────────────────

    /**
     * Возвращает текущий экземпляр конфигурации.
     * Если конфиг ещё не загружен — загружает из файла (или создаёт по умолчанию).
     */
    public static Stack67Config get() {
        if (instance == null) {
            instance = load();
        }
        return instance;
    }

    /**
     * Принудительная перезагрузка конфига из файла.
     * Полезно, если игрок изменил config/stack67.json на лету
     * и выполнил /stack67:reload (если добавите такую команду).
     */
    public static void reload() {
        instance = load();
        Stack67Mod.LOGGER.info("Конфиг Stack67 перезагружен: targetStackSize={}, replaceThreshold={}",
                instance.targetStackSize, instance.replaceThreshold);
    }

    // ── Загрузка / сохранение ────────────────────────────────────────

    /**
     * Загружает конфиг из файла. Если файл не существует или повреждён —
     * создаёт новый с настройками по умолчанию.
     */
    private static Stack67Config load() {
        Stack67Config config = new Stack67Config();

        if (Files.exists(CONFIG_PATH)) {
            try {
                String json = Files.readString(CONFIG_PATH);
                config = GSON.fromJson(json, Stack67Config.class);

                // Защита от null-полей (если JSON неполный)
                if (config == null) config = new Stack67Config();
                if (config.targetStackSize <= 0) config.targetStackSize = 67;
                if (config.replaceThreshold <= 0) config.replaceThreshold = 64;

                Stack67Mod.LOGGER.info(
                        "Конфиг Stack67 загружен: targetStackSize={}, replaceThreshold={}, enableLogging={}",
                        config.targetStackSize, config.replaceThreshold, config.enableLogging
                );

            } catch (IOException e) {
                Stack67Mod.LOGGER.error("Не удалось прочитать конфиг Stack67, используем значения по умолчанию", e);
            } catch (com.google.gson.JsonSyntaxException e) {
                Stack67Mod.LOGGER.error("Ошибка синтаксиса в config/stack67.json, используем значения по умолчанию", e);
            }
        } else {
            Stack67Mod.LOGGER.info("Конфиг не найден — создаём config/stack67.json с настройками по умолчанию");
        }

        // Всегда сохраняем — чтобы пользователь увидел файл и мог его отредактировать
        config.save();
        return config;
    }

    /**
     * Сохраняет текущий конфиг в файл.
     * Вызывается автоматически при первой загрузке (создаёт файл-шаблон).
     */
    public void save() {
        try {
            Files.createDirectories(CONFIG_PATH.getParent());
            String json = GSON.toJson(this);
            Files.writeString(CONFIG_PATH, json);
        } catch (IOException e) {
            Stack67Mod.LOGGER.error("Не удалось сохранить конфиг Stack67", e);
        }
    }

    // ── Валидация ────────────────────────────────────────────────────

    /**
     * Проверяет, допустимо ли данное значение targetStackSize.
     * Minecraft хранит maxCount как byte (0–127), но практически
     * значения >99 вызывают серьёзные баги в рендеринге.
     *
     * @return true, если значение в безопасном диапазоне
     */
    public static boolean isValidStackSize(int value) {
        return value >= 1 && value <= 99;
    }
}

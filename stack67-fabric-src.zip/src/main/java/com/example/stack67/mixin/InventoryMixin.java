package com.example.stack67.mixin;

import com.example.stack67.config.Stack67Config;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import net.minecraft.inventory.Inventory;

/**
 * ──────────────────────────────────────────────────────────────────────
 * InventoryMixin — САМЫЙ ВАЖНЫЙ Mixin во всём моде Stack67
 * ──────────────────────────────────────────────────────────────────────
 *
 * ПОЧЕМУ ЭТОТ MIXIN — КЛЮЧЕВОЙ:
 *
 *   Интерфейс Inventory — это КОРНЕВОЙ контрактор для ВСЕХ контейнеров
 *   в Minecraft. От него наследуют:
 *     • SimpleInventory  — сундуки, воронки (hoppers), разбрасыватели (droppers)
 *     • PlayerInventory  — инвентарь игрока
 *     • CraftingInventory — верстаки
 *     • И десятки других контейнеров через делегирование
 *
 *   Метод getMaxCountPerStack() определяет МАКСИМАЛЬНЫЙ размер стака,
 *   который контейнер готов принять в один слот. Если этот метод
 *   возвращает 64, то ВООБЩЕ НЕ ВАЖНО, что Item.getMaxCount()
 *   возвращает 67 — контейнер просто ОТВЕРГНЕТ предметы сверх 64!
 *
 *   Это объясняет, почему без этого Mixin'а:
 *     ✗ Воронки (hoppers) не передают стак >64 между контейнерами
 *     ✗ Разбрасыватели (droppers) не выбрасывают стак >64
 *     ✗ Сундуки (chests) не принимают стак >64 через Shift+клик
 *     ✗ Любой контейнер, основанный на SimpleInventory, ограничен 64
 *
 *   С этим Mixin'ом:
 *     ✓ Воронки корректно передают стак до targetStackSize
 *     ✓ Разбрасыватели работают без ограничений
 *     ✓ Shift+клик переносит стак полностью
 *     ✓ Все контейнеры на основе Inventory принимают увеличенный стак
 *
 *   ЛОГИКА ПЕРЕХВАТА:
 *     Мы используем @Inject(at = @At("RETURN"), cancellable = true),
 *     а не @Overwrite — это безопаснее и совместимее с другими модами.
 *     Если оригинальный метод вернул replaceThreshold (по умолчанию 64),
 *     мы заменяем результат на targetStackSize (по умолчанию 67).
 *     Если метод вернул другое значение (например, 1 для брони или
 *     16 для снежков) — мы НЕ вмешиваемся, сохраняя оригинальное поведение.
 *
 * ──────────────────────────────────────────────────────────────────────
 */
@Mixin(Inventory.class)
public interface InventoryMixin {

    /**
     * Перехват метода getMaxCountPerStack() на выходе.
     *
     * Если оригинальное значение совпадает с replaceThreshold (64),
     * заменяем его на targetStackSize из конфига.
     * Это «открывает» контейнер для принятия увеличенных стаков.
     *
     * @param cir  callback для управления возвращаемым значением
     */
    @Inject(method = "getMaxCountPerStack", at = @At("RETURN"), cancellable = true)
    private void stack67$overrideMaxCount(CallbackInfoReturnable<Integer> cir) {
        // Получаем текущие настройки из конфигурации
        Stack67Config config = Stack67Config.get();

        // Заменяем ТОЛЬКО если оригинальное значение совпадает с порогом
        // Это гарантирует, что мы не трогаем предметы со стеком 1, 16 и т.д.
        if (cir.getReturnValue() == config.replaceThreshold) {
            cir.setReturnValue(config.targetStackSize);
        }
    }
}

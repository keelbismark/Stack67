package com.example.stack67.mixin;

import com.example.stack67.Stack67Mod;
import com.example.stack67.config.Stack67Config;
import net.minecraft.item.Item;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * ──────────────────────────────────────────────────────────────────────
 * ItemMixin — подмешивание к классу net.minecraft.item.Item
 * ──────────────────────────────────────────────────────────────────────
 *
 * Цель: перехватить метод getMaxCount() и заменить значение
 * по порогу (по умолчанию 64 → 67) для всех подходящих предметов.
 *
 * Как работает @Mixin:
 *   Fabric/Mixin берёт байт-код класса Item и «подмешивает»
 *   наш метод. Аннотация @Inject указывает, что мы внедряемся
 *   в момент возврата значения (At("RETURN")) и можем его
 *   изменить (cancellable = true).
 *
 * Почему проверяем по порогу, а не строго == 64:
 *   Пользователь может захотеть изменить стаки с maxCount=16
 *   (жемчуг Края, снежки). Для этого достаточно поменять
 *   replaceThreshold в конфиге на 16. Дефолт — 64, что
 *   затрагивает только «обычные» стаки.
 *
 *   Предметы с maxCount = 1 (инструменты, броня) — НЕ трогаем,
 *   потому что это сломает механику durability.
 *
 * Конфигурируемость:
 *   Значения targetStackSize и replaceThreshold читаются из
 *   Stack67Config (файл config/stack67.json). Можно менять
 *   на лету без перекомпиляции мода.
 *
 * ВАЖНО: в Minecraft 1.20.5+ появился компонент max_stack_size,
 * который хранится в ItemStack. Этот Mixin меняет «дефолтный»
 * размер стака для типа предмета. Для уже существующих стеков
 * в мире см. ItemStackMixin.
 * ──────────────────────────────────────────────────────────────────────
 */
@Mixin(Item.class)
public abstract class ItemMixin {

    /**
     * Перехват метода Item#getMaxCount().
     *
     * @param cir  CallbackInfoReturnable<Integer> — объект, через который
     *             мы можем прочитать оригинальное возвращаемое значение
     *             и заменить его своим.
     */
    @Inject(method = "getMaxCount", at = @At("RETURN"), cancellable = true)
    private void stack67$modifyMaxStack(CallbackInfoReturnable<Integer> cir) {
        // Получаем текущие настройки из конфига
        Stack67Config config = Stack67Config.get();
        int original = cir.getReturnValue();

        // Отладочное логирование (ВЫКЛ по умолчанию, иначе спам на каждый тик)
        if (config.enableLogging) {
            Stack67Mod.LOGGER.debug("ItemMixin.getMaxCount: original={}, threshold={}, target={}",
                    original, config.replaceThreshold, config.targetStackSize);
        }

        // Если предмет стакается до порогового значения — заменяем на целевое
        if (original == config.replaceThreshold) {
            cir.setReturnValue(config.targetStackSize);
        }
        // Иначе (1, 16 и прочие нестандартные значения) — не трогаем
    }
}

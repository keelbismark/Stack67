package com.example.stack67.mixin;

import com.example.stack67.Stack67Mod;
import com.example.stack67.config.Stack67Config;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * ──────────────────────────────────────────────────────────────────────
 * ItemStackMixin — подмешивание к классу net.minecraft.item.ItemStack
 * ──────────────────────────────────────────────────────────────────────
 *
 * Зачем нужен этот Mixin, если есть ItemMixin:
 *
 *   Начиная с Minecraft 1.20.5, размер стака хранится как
 *   компонент данных (DataComponent) внутри ItemStack, а не
 *   только как поле в Item. Когда мир загружается с диска,
 *   существующие ItemStack уже содержат компонент max_stack_size=64.
 *   ItemMixin меняет только «дефолт» для НОВЫХ стеков, а старые
 *   продолжат думать, что их лимит — 64.
 *
 *   Этот Mixin перехватывает ItemStack#getMaxCount() и
 *   принудительно заменяет 64 → 67 (или другое значение из конфига),
 *   даже если компонент в конкретном стеке хранит 64.
 *
 *   Покрытие:
 *     ItemMixin      → новые предметы (при создании ItemStack)
 *     ItemStackMixin → существующие предметы (при загрузке мира,
 *                      при чтении из NBT, при крафте и т.д.)
 *
 * Потенциальные проблемы:
 *   - Компонент max_stack_size в NBT по-прежнему хранит 64.
 *     Это означает, что при удалении мода предметы вернутся
 *     к оригинальному лимиту — это безопасно.
 *   - Если другой мод читает max_stack_size напрямую из
 *     DataComponent (минуя getMaxCount()), он получит 64.
 *     Это редкий случай, но о нём стоит знать.
 * ──────────────────────────────────────────────────────────────────────
 */
@Mixin(ItemStack.class)
public abstract class ItemStackMixin {

    /**
     * Перехват метода ItemStack#getMaxCount().
     *
     * Логика: если метод возвращает значение, равное replaceThreshold,
     * подменяем на targetStackSize. Это срабатывает и для стеков,
     * у которых компонент max_stack_size уже сохранён как 64.
     */
    @Inject(method = "getMaxCount", at = @At("RETURN"), cancellable = true)
    private void stack67$modifyMaxStack(CallbackInfoReturnable<Integer> cir) {
        Stack67Config config = Stack67Config.get();
        int original = cir.getReturnValue();

        if (config.enableLogging) {
            Stack67Mod.LOGGER.debug("ItemStackMixin.getMaxCount: original={}, threshold={}, target={}",
                    original, config.replaceThreshold, config.targetStackSize);
        }

        // Заменяем по порогу; остальные значения не трогаем
        if (original == config.replaceThreshold) {
            cir.setReturnValue(config.targetStackSize);
        }
    }
}

package com.example.stack67.mixin;

import com.example.stack67.Stack67Mod;
import com.example.stack67.config.Stack67Config;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.Slot;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * ──────────────────────────────────────────────────────────────────────
 * SlotMixin — подмешивание к классу net.minecraft.screen.slot.Slot
 * ──────────────────────────────────────────────────────────────────────
 *
 * Зачем нужен ТРЕТИЙ Mixin:
 *
 *   Даже если Item и ItemStack сообщают, что максимальный стак = 67,
 *   контейнеры (сундуки, печки, воронки и т.д.) проверяют лимит
 *   через Slot.getMaxItemCount(ItemStack). Этот метод возвращает
 *   Math.min(inventory.getMaxCountPerStack(), itemStack.getMaxCount()).
 *
 *   Проблема: inventory.getMaxCountPerStack() для большинства
 *   ванильных контейнеров возвращает 64. Это означает, что даже
 *   при itemStack.getMaxCount() == 67, слот ограничит стек до 64.
 *
 *   Решение: перехватить Slot.getMaxItemCount() и если
 *   ItemStack допускает больший стак — вернуть это значение,
 *   проигнорировав лимит инвентаря.
 *
 * ПОБОЧНЫЕ ЭФФЕКТЫ:
 *   - Воронки могут переполняться (больше 64 предметов в одном слоте).
 *   - Автосортировка может работать некорректно.
 *   - Это НЕОБХОДИМАЯ жертва для работы стака >64 в контейнерах.
 *
 * БЕЗОПАСНОСТЬ:
 *   - Мы не меняем inventory.getMaxCountPerStack() глобально —
 *     только результат для конкретного слота.
 *   - Если предмет имеет maxCount <= replaceThreshold (например,
 *     инструменты с maxCount=1), Slot продолжает работать как обычно.
 * ──────────────────────────────────────────────────────────────────────
 */
@Mixin(Slot.class)
public abstract class SlotMixin {

    /**
     * Перехват метода Slot#getMaxItemCount(ItemStack).
     *
     * Оригинальная логика:
     *   return Math.min(this.inventory.getMaxCountPerStack(), stack.getMaxCount());
     *
     * Наша логика:
     *   Если ItemStack.getMaxCount() > inventory.getMaxCountPerStack()
     *   (т.е. наш мод увеличил лимит предмета), то возвращаем
     *   значение предмета, игнорируя лимит инвентаря.
     *
     *   Если ItemStack.getMaxCount() <= inventory.getMaxCountPerStack()
     *   (обычная ситуация для инструментов/брони), то ничего не меняем.
     */
    @Inject(method = "getMaxItemCount", at = @At("RETURN"), cancellable = true)
    private void stack67$modifySlotLimit(ItemStack stack, CallbackInfoReturnable<Integer> cir) {
        Stack67Config config = Stack67Config.get();
        int currentLimit = cir.getReturnValue();   // Math.min(invLimit, itemLimit)
        int itemLimit = stack.getMaxCount();     // Наше значение (67)

        // Если лимит предмета больше лимита слота — значит, наш мод
        // увеличил стак, но инвентарь его обрезает. Исправляем.
        if (itemLimit > currentLimit && itemLimit == config.targetStackSize) {
            cir.setReturnValue(itemLimit);

            if (config.enableLogging) {
                Stack67Mod.LOGGER.debug(
                        "SlotMixin: увеличен лимит слота {}→{} для предмета {}",
                        currentLimit, itemLimit, stack.getItem()
                );
            }
        }
    }
}

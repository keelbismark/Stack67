# Stack67 (NeoForge) — см. ../stack67-fabric/README.md для полной документации

Быстрый старт:
```bash
./gradlew build
# JAR → build/libs/stack67-neoforge-1.1.0.jar → .minecraft/mods/
```

Отличия от Fabric-версии:
- Аннотация @Mod вместо ModInitializer
- Mojang mappings (world.item.Item) вместо Yarn (item.Item)
- neoforge.mods.toml вместо fabric.mod.json
- FMLPaths.CONFIGDIR вместо FabricLoader.getConfigDir()

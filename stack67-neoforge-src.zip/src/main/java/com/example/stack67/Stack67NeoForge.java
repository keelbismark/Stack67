package com.example.stack67;

import com.example.stack67.commands.Stack67NeoForgeCommands;
import com.example.stack67.config.Stack67NeoForgeConfig;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.RegisterCommandsEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * ──────────────────────────────────────────────────────────────────────
 * Stack67NeoForge — главный класс мода «Stack67» для NeoForge
 * ──────────────────────────────────────────────────────────────────────
 *
 * Аннотация @Mod регистрирует класс как точку входа мода.
 * NeoForge автоматически находит его благодаря значению value,
 * которое должно совпадать с modId в neoforge.mods.toml.
 *
 * Что делает этот мод:
 *   С помощью Mixin перехватывает методы Item#getMaxStackSize(),
 *   ItemStack#getMaxStackSize(), Slot#getMaxStackSize(ItemStack)
 *   и Container#getMaxStackSize() — заменяет возвращаемое значение
 *   по порогу (64 → 67 по умолчанию).
 *
 * Архитектура v1.2.0:
 *   - ContainerMixin: перехват Container#getMaxStackSize() для поддержки
 *     увеличенного стака в контейнерах (сундуки, печки и т.д.)
 *   - Stack67NeoForgeCommands: команды /stack67 (help, reload, status, set)
 *   - Stack67NeoForgeConfig: конфигурация на основе ModConfigSpec
 *     (стандартная система NeoForge вместо пользовательского JSON)
 *
 * Отличия от Fabric-версии:
 *   - Используется @Mod вместо ModInitializer
 *   - Конструктор с ModContainer вместо onInitialize()
 *   - Конфигурация через ModConfigSpec (TOML) вместо JSON
 *   - Команды через RegisterCommandsEvent вместо CommandRegistrationCallback
 *   - NeoForge ModDev автоматически подключает Mixin
 *
 * ВНИМАНИЕ: Стак >64 может вызывать баги UI в контейнерах и рецептах.
 *           См. подробности в README → «Известные ограничения».
 * ──────────────────────────────────────────────────────────────────────
 */
@Mod(Stack67NeoForge.MOD_ID)
public class Stack67NeoForge {

    /** Уникальный идентификатор мода — должен совпадать с modId в neoforge.mods.toml */
    public static final String MOD_ID = "stack67";

    /** Логгер для вывода сообщений в консоль игры / лог-файлы */
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    /**
     * Конструктор мода.
     * NeoForge создаёт экземпляр этого класса один раз при загрузке.
     * Аналог onInitialize() в Fabric.
     *
     * @param modContainer контейнер мода NeoForge — используется для
     *                     регистрации конфигурации (ModConfigSpec)
     */
    public Stack67NeoForge(ModContainer modContainer) {
        // Регистрируем конфигурацию на основе ModConfigSpec
        // Файл: config/stack67-neoforge-common.toml
        modContainer.registerConfig(ModConfig.Type.COMMON, Stack67NeoForgeConfig.SPEC);

        // Подписываемся на событие регистрации команд
        NeoForge.EVENT_BUS.addListener(this::onRegisterCommands);

        LOGGER.info("╔══════════════════════════════════════════╗");
        LOGGER.info("║  Stack67 (NeoForge) v1.2.0 загружен     ║");
        LOGGER.info("║  Целевой размер стака: {}               ║", Stack67NeoForgeConfig.getTargetStackSize());
        LOGGER.info("║  Порог замены: {}                       ║", Stack67NeoForgeConfig.getReplaceThreshold());
        LOGGER.info("║  Конфиг: ModConfigSpec (TOML)           ║");
        LOGGER.info("║  Команды: /stack67                      ║");
        LOGGER.info("╚══════════════════════════════════════════╝");

        if (Stack67NeoForgeConfig.getTargetStackSize() > 99) {
            LOGGER.warn("⚠ Stack67: targetStackSize={} > 99 — серьёзные баги рендеринга!",
                    Stack67NeoForgeConfig.getTargetStackSize());
        }
    }

    /**
     * Обработчик события регистрации команд.
     * Вызывается NeoForge при инициализации командного дерева.
     *
     * @param event событие регистрации команд Brigadier
     */
    private void onRegisterCommands(RegisterCommandsEvent event) {
        Stack67NeoForgeCommands.register(event.getDispatcher());
    }
}

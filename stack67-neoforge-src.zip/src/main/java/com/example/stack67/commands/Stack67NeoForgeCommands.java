package com.example.stack67.commands;

import com.example.stack67.Stack67NeoForge;
import com.example.stack67.config.Stack67NeoForgeConfig;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;

/**
 * ──────────────────────────────────────────────────────────────────────
 * Stack67NeoForgeCommands — регистрация команд мода /stack67
 * (NeoForge Brigadier)
 * ──────────────────────────────────────────────────────────────────────
 *
 * Регистрирует следующие команды:
 *
 *   /stack67           — отображает справку по командам мода
 *   /stack67 reload    — перезагружает конфигурацию из файла (требует OP 2)
 *   /stack67 status    — показывает текущие параметры конфигурации
 *   /stack67 set <N>   — устанавливает целевой размер стака (1–127, требует OP 2)
 *
 * Команды используют стандартный Brigadier API NeoForge.
 * Регистрация происходит через событие RegisterCommandsEvent,
 * на которое подписывается главный класс мода.
 *
 * Для OP-команд используется .requires(source -> source.hasPermission(2)),
 * что соответствует уровню 2 (оператор сервера).
 * ──────────────────────────────────────────────────────────────────────
 */
public class Stack67NeoForgeCommands {

    /**
     * Регистрирует все команды мода /stack67 в диспетчере команд.
     *
     * @param dispatcher диспетчер команд Brigadier
     */
    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(
                Commands.literal("stack67")
                        /* /stack67 — справка по командам */
                        .executes(context -> {
                            CommandSourceStack source = context.getSource();
                            source.sendSuccess(() ->
                                    Component.literal("§6=== Stack67 v1.2.0 ===")
                                            .append(Component.literal("\n§e/stack67 §7— показать эту справку"))
                                            .append(Component.literal("\n§e/stack67 reload §7— перезагрузить конфиг (OP 2)"))
                                            .append(Component.literal("\n§e/stack67 status §7— текущие параметры"))
                                            .append(Component.literal("\n§e/stack67 set <1-127> §7— установить размер стака (OP 2)"))
                            , false);
                            return 1;
                        })

                        /* /stack67 reload — перезагрузка конфигурации (только OP 2) */
                        .then(Commands.literal("reload")
                                .requires(source -> source.hasPermission(2))
                                .executes(context -> {
                                    CommandSourceStack source = context.getSource();

                                    // Перезагружаем конфигурацию из файла
                                    

                                    source.sendSuccess(() ->
                                            Component.literal("§a[Stack67] Конфигурация перезагружена.")
                                                    .append(Component.literal("\n§7  Целевой размер стака: §e"
                                                            + Stack67NeoForgeConfig.getTargetStackSize()))
                                                    .append(Component.literal("\n§7  Порог замены: §e"
                                                            + Stack67NeoForgeConfig.getReplaceThreshold()))
                                                    .append(Component.literal("\n§7  Логирование: §e"
                                                            + Stack67NeoForgeConfig.isEnableLogging()))
                                    , true);
                                    return 1;
                                })
                        )

                        /* /stack67 status — текущие параметры конфигурации */
                        .then(Commands.literal("status")
                                .executes(context -> {
                                    CommandSourceStack source = context.getSource();
                                    source.sendSuccess(() ->
                                            Component.literal("§6[Stack67] Текущая конфигурация:")
                                                    .append(Component.literal("\n§7  Целевой размер стака: §e"
                                                            + Stack67NeoForgeConfig.getTargetStackSize()))
                                                    .append(Component.literal("\n§7  Порог замены: §e"
                                                            + Stack67NeoForgeConfig.getReplaceThreshold()))
                                                    .append(Component.literal("\n§7  Логирование: §e"
                                                            + Stack67NeoForgeConfig.isEnableLogging()))
                                                    .append(Component.literal("\n§7  Версия: §ev1.2.0"))
                                    , false);
                                    return 1;
                                })
                        )

                        /* /stack67 set <1-127> — установка целевого размера стака (только OP 2) */
                        .then(Commands.literal("set")
                                .requires(source -> source.hasPermission(2))
                                .then(Commands.argument("size", com.mojang.brigadier.arguments.IntegerArgumentType.integer(1, 127))
                                        .executes(context -> {
                                            int newSize = com.mojang.brigadier.arguments.IntegerArgumentType.getInteger(context, "size");
                                            CommandSourceStack source = context.getSource();

                                            // Устанавливаем новое значение и сохраняем конфигурацию
                                            Stack67NeoForgeConfig.setTargetStackSize(newSize);

                                            Stack67NeoForge.LOGGER.info(
                                                    "[Stack67] Целевой размер стака изменён на {} (инициатор: {})",
                                                    newSize, source.getTextName()
                                            );

                                            source.sendSuccess(() ->
                                                    Component.literal("§a[Stack67] Целевой размер стака установлен: §e" + newSize)
                                                            .append(Component.literal("\n§7  Порог замены: §e"
                                                                    + Stack67NeoForgeConfig.getReplaceThreshold()))
                                                            .append(Component.literal("\n§7  Перезапустите сервер для полного применения."))
                                            , true);
                                            return 1;
                                        })
                                )
                        )
        );

        Stack67NeoForge.LOGGER.debug("[Stack67] Команды /stack67 зарегистрированы");
    }
}

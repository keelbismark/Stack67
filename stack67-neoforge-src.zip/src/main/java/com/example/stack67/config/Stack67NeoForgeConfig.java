package com.example.stack67.config;

import net.neoforged.neoforge.common.ModConfigSpec;

/**
 * ──────────────────────────────────────────────────────────────────────
 * Stack67NeoForgeConfig — конфигурация мода на основе ModConfigSpec
 * (стандартная система конфигурации NeoForge)
 * ──────────────────────────────────────────────────────────────────────
 *
 * Начиная с версии 1.2.0 мод переходит с пользовательского JSON-конфига
 * (Stack67Config) на стандартную систему NeoForge ModConfigSpec.
 *
 * Преимущества ModConfigSpec над пользовательским JSON-конфигом:
 *
 *   1. Автоматическая синхронизация — сервер автоматически отправляет
 *      конфигурацию подключившимся клиентам, гарантируя一致性.
 *
 *   2. Встроенная валидация — диапазоны значений (range), обязательные
 *      поля и значения по умолчанию проверяются на этапе загрузки.
 *
 *   3. Формат TOML — человекочитаемый и стандартный для NeoForge/Forge,
 *      с поддержкой комментариев прямо в файле конфигурации.
 *
 *   4. Горячая перезагрузка — изменения в файле подхватываются без
 *      перезапуска игры (для COMMON-типа конфигурации).
 *
 *   5. Интеграция с командами — значения можно менять через консоль
 *      и сохранять программно через SPEC.save().
 *
 *   6. Автогенерация — файл конфигурации создаётся автоматически при
 *      первом запуске с комментариями и значениями по умолчанию.
 *
 * Файл конфигурации: config/stack67-neoforge-common.toml
 * ──────────────────────────────────────────────────────────────────────
 */
public class Stack67NeoForgeConfig {

    /** Спецификация конфигурации — регистрируется через modContainer.registerConfig() */
    public static final ModConfigSpec SPEC;

    /** Целевой размер стака (вместо 64) — по умолчанию 67 */
    private static final ModConfigSpec.IntValue TARGET_STACK_SIZE;

    /** Порог замены: заменяем стаки, у которых maxStackSize == replaceThreshold */
    private static final ModConfigSpec.IntValue REPLACE_THRESHOLD;

    /** Включить подробное логирование Mixin-перехватов (ОСТОРОЖНО: очень спамно) */
    private static final ModConfigSpec.BooleanValue ENABLE_LOGGING;

    static {
        ModConfigSpec.Builder builder = new ModConfigSpec.Builder();

        builder.push("general");

        TARGET_STACK_SIZE = builder
                .comment("Целевой размер стака. Предметы с maxStackSize == replaceThreshold будут иметь этот размер стака.",
                         "По умолчанию 67. Диапазон: 1–127. Значения >99 могут вызывать баги рендеринга.")
                .defineInRange("targetStackSize", 67, 1, 127);

        REPLACE_THRESHOLD = builder
                .comment("Порог замены. Если maxStackSize предмета равен этому значению, он будет заменён на targetStackSize.",
                         "По умолчанию 64 (стандартный стак Minecraft). Диапазон: 2–127.",
                         "Не устанавливайте значение 1 — это сломает предметы с maxSize=1 (инструменты и т.д.).")
                .defineInRange("replaceThreshold", 64, 2, 127);

        ENABLE_LOGGING = builder
                .comment("Включить подробное логирование Mixin-перехватов.",
                         "ОСТОРОЖНО: генерирует ОЧЕНЬ много сообщений в логе! Только для отладки.",
                         "По умолчанию false.")
                .define("enableLogging", false);

        builder.pop();

        SPEC = builder.build();
    }

    /**
     * Возвращает целевой размер стака из конфигурации.
     *
     * @return целевой размер стака (по умолчанию 67)
     */
    public static int getTargetStackSize() {
        return TARGET_STACK_SIZE.get();
    }

    /**
     * Возвращает порог замены из конфигурации.
     *
     * @return порог замены (по умолчанию 64)
     */
    public static int getReplaceThreshold() {
        return REPLACE_THRESHOLD.get();
    }

    /**
     * Проверяет, включено ли подробное логирование.
     *
     * @return true, если логирование включено
     */
    public static boolean isEnableLogging() {
        return ENABLE_LOGGING.get();
    }

    /**
     * Устанавливает новое значение целевого размера стака и сохраняет конфигурацию.
     * Используется командой /stack67 set.
     *
     * @param newSize новый целевой размер стака (1–127)
     */
    public static void setTargetStackSize(int newSize) {
        TARGET_STACK_SIZE.set(newSize);
        SPEC.save();
    }
}

package com.example.stack67.mixin;

import com.example.stack67.Stack67NeoForge;
import com.example.stack67.config.Stack67NeoForgeConfig;
import net.minecraft.world.Container;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * ──────────────────────────────────────────────────────────────────────
 * ContainerMixin — подмешивание к net.minecraft.world.Container
 * (NeoForge-версия, Mojang mappings)
 * ──────────────────────────────────────────────────────────────────────
 *
 * Контейнер (Container) — это интерфейс, который определяет лимит
 * стака для хранилища предметов (сундуки, печки и т.д.).
 * Метод getMaxStackSize() по умолчанию возвращает 64.
 *
 * Данный Mixin перехватывает Container#getMaxStackSize() и заменяет
 * возвращаемое значение, если оно совпадает с порогом замены из конфига.
 * Это необходимо, чтобы контейнеры также поддерживали увеличенный
 * размер стака (например, 67 вместо 64).
 *
 * Без этого Mixin контейнеры ограничивали бы стек до 64, даже если
 * Item#getMaxStackSize() уже возвращает 67 — предметы просто не
 * помещались бы в контейнер сверх стандартного лимита.
 *
 * Использует Stack67NeoForgeConfig (ModConfigSpec), а не устаревший
 * Stack67Config (JSON), так как v1.2.0 переходит на стандартную
 * систему конфигурации NeoForge.
 * ──────────────────────────────────────────────────────────────────────
 */
@Mixin(Container.class)
public interface ContainerMixin {

    /**
     * Перехват метода getMaxStackSize() на этапе возврата значения.
     *
     * Если оригинальное значение совпадает с порогом замены
     * (по умолчанию 64), оно заменяется на целевой размер стака
     * (по умолчанию 67) из Stack67NeoForgeConfig.
     *
     * @param cir обратный вызов для управления возвращаемым значением
     */
    @Inject(method = "getMaxStackSize", at = @At("RETURN"), cancellable = true)
    private void stack67$modifyContainerMaxStack(CallbackInfoReturnable<Integer> cir) {
        int original = cir.getReturnValue();

        if (Stack67NeoForgeConfig.isEnableLogging()) {
            Stack67NeoForge.LOGGER.debug("ContainerMixin.getMaxStackSize: original={}", original);
        }

        if (original == Stack67NeoForgeConfig.getReplaceThreshold()) {
            cir.setReturnValue(Stack67NeoForgeConfig.getTargetStackSize());
        }
    }
}

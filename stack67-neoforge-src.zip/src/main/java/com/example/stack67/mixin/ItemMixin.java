package com.example.stack67.mixin;

import com.example.stack67.Stack67NeoForge;
import com.example.stack67.config.Stack67NeoForgeConfig;
import net.minecraft.world.item.Item;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * ──────────────────────────────────────────────────────────────────────
 * ItemMixin — подмешивание к классу net.minecraft.world.item.Item
 * (NeoForge-версия, использует Mojang mappings вместо Yarn)
 * ──────────────────────────────────────────────────────────────────────
 *
 * В NeoForge используются Mojang mappings (world.item.Item),
 * а не Yarn (item.Item). Имена методов те же (getMaxStackSize),
 * но пакеты другие. Это единственное отличие от Fabric-версии.
 *
 * Цель идентична: перехватить getMaxStackSize() и заменить
 * значение по порогу (по умолчанию 64 → 67).
 *
 * ВАЖНО: NeoForge ModDev автоматически регистрирует Mixin-классы,
 *        дополнительные настройки в neoforge.mods.toml не нужны
 *        (в отличие от Fabric, где нужен mixins.json).
 * ──────────────────────────────────────────────────────────────────────
 */
@Mixin(Item.class)
public abstract class ItemMixin {

    @Inject(method = "getMaxStackSize", at = @At("RETURN"), cancellable = true)
    private void stack67$modifyMaxStack(CallbackInfoReturnable<Integer> cir) {
        int original = cir.getReturnValue();

        if (Stack67NeoForgeConfig.isEnableLogging()) {
            Stack67NeoForge.LOGGER.debug("ItemMixin.getMaxStackSize: original={}", original);
        }

        if (original == Stack67NeoForgeConfig.getReplaceThreshold()) {
            cir.setReturnValue(Stack67NeoForgeConfig.getTargetStackSize());
        }
    }
}

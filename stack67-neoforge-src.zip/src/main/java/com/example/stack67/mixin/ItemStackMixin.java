package com.example.stack67.mixin;

import com.example.stack67.config.Stack67NeoForgeConfig;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * ──────────────────────────────────────────────────────────────────────
 * ItemStackMixin — подмешивание к net.minecraft.world.item.ItemStack
 * (NeoForge-версия, Mojang mappings)
 * ──────────────────────────────────────────────────────────────────────
 *
 * Идентичен Fabric-версии по логике. Перехватывает
 * ItemStack#getMaxStackSize() и заменяет 64 → 67 (из конфига).
 *
 * В NeoForge используется пакет world.item.ItemStack вместо item.ItemStack.
 * ──────────────────────────────────────────────────────────────────────
 */
@Mixin(ItemStack.class)
public abstract class ItemStackMixin {

    @Inject(method = "getMaxStackSize", at = @At("RETURN"), cancellable = true)
    private void stack67$modifyMaxStack(CallbackInfoReturnable<Integer> cir) {
        int original = cir.getReturnValue();

        if (original == Stack67NeoForgeConfig.getReplaceThreshold()) {
            cir.setReturnValue(Stack67NeoForgeConfig.getTargetStackSize());
        }
    }
}

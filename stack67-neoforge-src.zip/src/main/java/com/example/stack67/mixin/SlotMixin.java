package com.example.stack67.mixin;

import com.example.stack67.Stack67NeoForge;
import com.example.stack67.config.Stack67NeoForgeConfig;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * ──────────────────────────────────────────────────────────────────────
 * SlotMixin — подмешивание к net.minecraft.world.inventory.Slot
 * (NeoForge-версия, Mojang mappings)
 * ──────────────────────────────────────────────────────────────────────
 *
 * Идентичен Fabric-версии по логике. Расширяет лимит слота в
 * контейнерах, чтобы предметы со стеком >64 могли быть помещены.
 *
 * В NeoForge используется пакет world.inventory.Slot вместо screen.slot.Slot.
 * ──────────────────────────────────────────────────────────────────────
 */
@Mixin(Slot.class)
public abstract class SlotMixin {

    @Inject(method = "getMaxStackSize", at = @At("RETURN"), cancellable = true)
    private void stack67$modifySlotLimit(ItemStack stack, CallbackInfoReturnable<Integer> cir) {
        int currentLimit = cir.getReturnValue();
        int itemLimit = stack.getMaxStackSize();

        if (itemLimit > currentLimit && itemLimit == Stack67NeoForgeConfig.getTargetStackSize()) {
            cir.setReturnValue(itemLimit);

            if (Stack67NeoForgeConfig.isEnableLogging()) {
                Stack67NeoForge.LOGGER.debug(
                        "SlotMixin: лимит слота {}→{} для {}",
                        currentLimit, itemLimit, stack.getItem()
                );
            }
        }
    }
}

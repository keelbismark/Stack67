# Stack67 (Spigot/Paper) — Плагин для изменения максимального стака

> Быстрый старт:
> ```bash
> mvn clean package
> # JAR → target/stack67-1.2.0.jar → plugins/
> ```
>
> Полная документация: ../stack67-fabric/README.md

## Отличия от Fabric/NeoForge

| Аспект | Fabric/NeoForge | Spigot/Paper |
|--------|----------------|--------------|
| Метод | Mixin (байт-код) | Reflection / ByteBuddy |
| Доступ | Полный (Mixin) | NMS (хрупкий) |
| Конфиг | JSON / TOML | YAML (config.yml) |
| Команды | Brigadier | Bukkit CommandExecutor |
| Классы | Yarn / Mojang mappings | NMS versioned |

## Как это работает

Плагин использует **reflection** для доступа к приватному полю `maxStackSize` в NMS-классе `Item`. Поскольку Bukkit API (`Material.getMaxStackSize()`) — только для чтения, прямое изменение NMS — единственный способ изменить размер стака.

Два режима:
- **Reflection** — быстро, но может не работать если SecurityManager заблокирован
- **ByteBuddy** — надёжнее, но требует больше памяти

## Структура

```
stack67-spigot/
├── pom.xml
├── src/main/
│   ├── java/com/example/stack67/
│   │   ├── Stack67Plugin.java     ← JavaPlugin (точка входа)
│   │   ├── nms/
│   │   │   └── NMSHelper.java     ← Reflection / ByteBuddy для NMS
│   │   ├── config/
│   │   │   └── Stack67SpigotConfig.java  ← config.yml
│   │   └── commands/
│   │       └── Stack67Command.java ← /stack67
│   └── resources/
│       ├── plugin.yml
│       └── config.yml
```

## Команды

```
/stack67 status   → текущие настройки
/stack67 reload   → перезагрузить конфиг (OP)
/stack67 set 99   → изменить targetStackSize (OP)
```

## ВНИМАНИЕ

NMS-доступ **ломается при каждом обновлении Minecraft**. Проверяйте совместимость!

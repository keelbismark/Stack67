package com.example.stack67;

import com.example.stack67.commands.Stack67Command;
import com.example.stack67.config.Stack67SpigotConfig;
import com.example.stack67.nms.NMSHelper;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * ──────────────────────────────────────────────────────────────────────
 * Stack67Plugin — главный класс плагина «Stack67» для Spigot/Paper
 * ──────────────────────────────────────────────────────────────────────
 *
 * Отличие плагина от мода:
 *   Моды (Fabric/NeoForge) работают НА УРОВНЕ БАЙТ-КОДА Minecraft —
 *   они могут подмешивать (Mixin) свой код прямо в ванильные классы.
 *   Плагины работают НА УРОВНЕ API Bukkit/Spigot — у них нет доступа
 *   к внутренним классам Minecraft напрямую.
 *
 * Поэтому для изменения getMaxStackSize() мы используем reflection —
 * прямой доступ к приватному полю maxStackSize в NMS-классе Item через
 * CraftMagicNumbers.getItem().
 *
 * Поддержка платформ:
 *   - Paper 1.20.5+: Mojang mappings (net.minecraft.world.item.Item)
 *   - Spigot 1.20.5+: SRG mappings (обфусцированные имена)
 *   - Автоопределение: плагин проверяет наличие Paper API
 *     и выбирает правильную стратегию доступа
 *
 * ВНИМАНИЕ: Стак >64 может вызывать баги UI в контейнерах и рецептах.
 *           См. подробности в README → «Известные ограничения».
 * ──────────────────────────────────────────────────────────────────────
 */
public class Stack67Plugin extends JavaPlugin {

    /** Префикс для сообщений в чате */
    public static final String PREFIX = ChatColor.AQUA + "[Stack67]" + ChatColor.RESET + " ";

    /** Экземпляр плагина (singleton) */
    private static Stack67Plugin instance;

    /** NMS-утилита для модификации стака */
    private NMSHelper nmsHelper;

    // ── Жизненный цикл плагина ──────────────────────────────────────

    /**
     * Вызывается при включении плагина.
     * Здесь мы:
     *   1. Загружаем конфигурацию
     *   2. Инициализируем NMS-утилиту
     *   3. Применяем изменения стака через reflection
     *   4. Регистрируем команды
     */
    @Override
    public void onEnable() {
        instance = this;

        // 1. Загружаем конфигурацию (config.yml)
        saveDefaultConfig();
        Stack67SpigotConfig.load(getConfig());

        // 2. Инициализируем NMS-утилиту
        nmsHelper = new NMSHelper(this);

        // 3. Применяем изменения стака
        boolean success = applyStackChanges();

        // 4. Регистрируем команды
        if (getCommand("stack67") != null) {
            getCommand("stack67").setExecutor(new Stack67Command(this));
            getCommand("stack67").setTabCompleter(new Stack67Command(this));
        }

        // 5. Логирование
        if (success) {
            getLogger().info("╔══════════════════════════════════════════════╗");
            getLogger().info("║  Stack67 (Spigot/Paper) v1.2.0 загружен      ║");
            getLogger().info("║  Целевой размер стака: " + Stack67SpigotConfig.getTargetStackSize());
            getLogger().info("║  Порог замены: " + Stack67SpigotConfig.getReplaceThreshold());
            getLogger().info("║  Платформа: " + (isPaper() ? "Paper" : "Spigot"));
            getLogger().info("║  Команды: /stack67 reload|status|set         ║");
            getLogger().info("╚══════════════════════════════════════════════╝");
        } else {
            getLogger().severe("Не удалось применить изменения стака! Проверьте совместимость версий.");
            getLogger().severe("Плагин будет работать в режиме «только статус».");
        }
    }

    /**
     * Вызывается при отключении плагина.
     * Восстанавливаем оригинальные значения maxStackSize.
     */
    @Override
    public void onDisable() {
        if (nmsHelper != null) {
            nmsHelper.restoreDefaults();
            getLogger().info("Stack67: оригинальные размеры стаков восстановлены");
        }
    }

    // ── Применение изменений ────────────────────────────────────────

    /**
     * Применяет изменения максимального стака ко всем предметам.
     *
     * Итерирует все Material'ы в Bukkit и для каждого, у которого
     * maxStackSize == replaceThreshold, меняет на targetStackSize
     * через NMS reflection.
     *
     * @return true если хотя бы один предмет был изменён
     */
    private boolean applyStackChanges() {
        if (!nmsHelper.isAvailable()) return false;

        int targetSize = Stack67SpigotConfig.getTargetStackSize();
        int threshold = Stack67SpigotConfig.getReplaceThreshold();
        int modified = 0;
        int failed = 0;

        for (Material material : Material.values()) {
            // Пропускаем воздух и не-предметы
            if (material.isAir() || !material.isItem()) continue;

            try {
                int currentMax = material.getMaxStackSize();
                if (currentMax == threshold) {
                    boolean ok = nmsHelper.setMaxStackSize(material, targetSize);
                    if (ok) {
                        modified++;
                    } else {
                        failed++;
                    }
                }
            } catch (Exception e) {
                failed++;
                if (Stack67SpigotConfig.isEnableLogging()) {
                    getLogger().warning("Не удалось изменить стак для " + material.name() + ": " + e.getMessage());
                }
            }
        }

        getLogger().info("Изменено предметов: " + modified + ", ошибок: " + failed);
        return modified > 0;
    }

    // ── Утилитарные методы ──────────────────────────────────────────

    /**
     * Проверяет, запущен ли плагин на Paper (а не на чистом Spigot).
     * Paper использует Mojang mappings, что упрощает reflection.
     */
    public static boolean isPaper() {
        try {
            Class.forName("io.papermc.paper.configuration.GlobalConfiguration");
            return true;
        } catch (ClassNotFoundException e) {
            return false;
        }
    }

    /**
     * Возвращает экземпляр плагина.
     */
    public static Stack67Plugin getInstance() {
        return instance;
    }

    /**
     * Возвращает NMS-утилиту.
     */
    public NMSHelper getNmsHelper() {
        return nmsHelper;
    }

    /**
     * Перезагружает конфигурацию и повторно применяет изменения.
     * Вызывается из команды /stack67 reload.
     */
    public void reload() {
        // Сначала восстанавливаем дефолты
        nmsHelper.restoreDefaults();

        // Перезагружаем конфиг
        reloadConfig();
        Stack67SpigotConfig.load(getConfig());

        // Применяем заново
        applyStackChanges();
    }
}

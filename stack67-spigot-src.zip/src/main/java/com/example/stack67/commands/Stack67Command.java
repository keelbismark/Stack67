package com.example.stack67.commands;

import com.example.stack67.Stack67Plugin;
import com.example.stack67.config.Stack67SpigotConfig;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;

import java.util.ArrayList;
import java.util.List;

/**
 * ──────────────────────────────────────────────────────────────────────
 * Stack67Command — обработчик команд /stack67 для Spigot/Paper
 * ──────────────────────────────────────────────────────────────────────
 *
 * Команды:
 *   /stack67          — справка
 *   /stack67 status   — текущие настройки (доступна всем)
 *   /stack67 reload   — перезагрузить конфиг (OP)
 *   /stack67 set <n>  — изменить targetStackSize (OP)
 *
 * Реализует CommandExecutor и TabCompleter — стандартные
 * интерфейсы Bukkit для обработки команд и автодополнения.
 * ──────────────────────────────────────────────────────────────────────
 */
public class Stack67Command implements CommandExecutor, TabCompleter {

    private final Stack67Plugin plugin;

    public Stack67Command(Stack67Plugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            sendHelp(sender);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "status" -> sendStatus(sender);
            case "reload" -> {
                if (!sender.hasPermission("stack67.admin")) {
                    sender.sendMessage(Stack67Plugin.PREFIX + ChatColor.RED + "Нет прав!");
                    return true;
                }
                plugin.reload();
                sender.sendMessage(Stack67Plugin.PREFIX + ChatColor.GREEN +
                        "Конфиг перезагружен: targetStackSize=" + Stack67SpigotConfig.getTargetStackSize());
            }
            case "set" -> {
                if (!sender.hasPermission("stack67.admin")) {
                    sender.sendMessage(Stack67Plugin.PREFIX + ChatColor.RED + "Нет прав!");
                    return true;
                }
                if (args.length < 2) {
                    sender.sendMessage(Stack67Plugin.PREFIX + ChatColor.RED + "Использование: /stack67 set <1-127>");
                    return true;
                }
                try {
                    int newSize = Integer.parseInt(args[1]);
                    if (newSize < 1 || newSize > 127) {
                        sender.sendMessage(Stack67Plugin.PREFIX + ChatColor.RED + "Значение должно быть от 1 до 127");
                        return true;
                    }
                    Stack67SpigotConfig.setTargetStackSize(newSize, plugin.getConfig());
                    plugin.saveConfig();
                    // Повторно применяем изменения
                    plugin.reload();
                    sender.sendMessage(Stack67Plugin.PREFIX + ChatColor.GREEN +
                            "targetStackSize: " + newSize);
                } catch (NumberFormatException e) {
                    sender.sendMessage(Stack67Plugin.PREFIX + ChatColor.RED + "Введите число!");
                }
            }
            default -> sendHelp(sender);
        }
        return true;
    }

    /**
     * Отправляет справку по командам.
     */
    private void sendHelp(CommandSender sender) {
        sender.sendMessage(ChatColor.AQUA + "═══ Stack67 v1.2.0 ═══");
        sender.sendMessage(ChatColor.YELLOW + "/stack67 status" + ChatColor.GRAY + " — текущие настройки");
        if (sender.hasPermission("stack67.admin")) {
            sender.sendMessage(ChatColor.YELLOW + "/stack67 reload" + ChatColor.GRAY + " — перезагрузить конфиг");
            sender.sendMessage(ChatColor.YELLOW + "/stack67 set <n>" + ChatColor.GRAY + " — изменить targetStackSize");
        }
    }

    /**
     * Отправляет текущий статус конфигурации.
     */
    private void sendStatus(CommandSender sender) {
        sender.sendMessage(ChatColor.AQUA + "═══ Stack67 — Статус ═══");
        sender.sendMessage("  targetStackSize = " + ChatColor.GREEN + Stack67SpigotConfig.getTargetStackSize());
        sender.sendMessage("  replaceThreshold = " + ChatColor.GREEN + Stack67SpigotConfig.getReplaceThreshold());
        sender.sendMessage("  enableLogging = " + ChatColor.GREEN + Stack67SpigotConfig.isEnableLogging());
        sender.sendMessage("  platform = " + ChatColor.GREEN + (Stack67Plugin.isPaper() ? "Paper" : "Spigot"));
        sender.sendMessage("  NMS available = " + ChatColor.GREEN + plugin.getNmsHelper().isAvailable());
        sender.sendMessage(ChatColor.GRAY + "  Конфиг: plugins/Stack67/config.yml");
    }

    /**
     * Автодополнение для Tab-клавиши.
     */
    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> completions = new ArrayList<>();

        if (args.length == 1) {
            completions.add("status");
            if (sender.hasPermission("stack67.admin")) {
                completions.add("reload");
                completions.add("set");
            }
        } else if (args.length == 2 && args[0].equalsIgnoreCase("set")) {
            completions.add("67");
            completions.add("99");
        }

        // Фильтруем по введённому префиксу
        String prefix = args[args.length - 1].toLowerCase();
        completions.removeIf(s -> !s.toLowerCase().startsWith(prefix));
        return completions;
    }
}

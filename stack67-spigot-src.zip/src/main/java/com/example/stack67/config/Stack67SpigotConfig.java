package com.example.stack67.config;

import org.bukkit.configuration.file.FileConfiguration;

/**
 * ──────────────────────────────────────────────────────────────────────
 * Stack67SpigotConfig — конфигурация плагина для Spigot/Paper
 * ──────────────────────────────────────────────────────────────────────
 *
 * Читает config.yml (стандартный формат Bukkit).
 * В отличие от Fabric (JSON) и NeoForge (TOML + ModConfigSpec),
 * Spigot использует YAML — самый читаемый формат для ручного редактирования.
 *
 * Преимущества YAML для серверных администраторов:
 *   - Поддержка комментариев (#) прямо в файле
 *   - Простой синтаксис (ключ: значение)
 *   - Автоматическое создание при первом запуске (saveDefaultConfig)
 *   - Поддержка иерархии (вложенные категории)
 *
 * Использование:
 *   Stack67SpigotConfig.load(getConfig());  // Загрузить
 *   int size = Stack67SpigotConfig.getTargetStackSize();  // Прочитать
 * ──────────────────────────────────────────────────────────────────────
 */
public class Stack67SpigotConfig {

    private static int targetStackSize = 67;
    private static int replaceThreshold = 64;
    private static boolean enableLogging = false;

    /**
     * Загружает конфигурацию из FileConfiguration (config.yml).
     * Вызывается в onEnable() и при /stack67 reload.
     *
     * @param config  FileConfiguration из JavaPlugin.getConfig()
     */
    public static void load(FileConfiguration config) {
        targetStackSize = config.getInt("targetStackSize", 67);
        replaceThreshold = config.getInt("replaceThreshold", 64);
        enableLogging = config.getBoolean("enableLogging", false);

        // Валидация
        if (targetStackSize < 1) targetStackSize = 67;
        if (targetStackSize > 127) targetStackSize = 127;
        if (replaceThreshold < 2) replaceThreshold = 64;
        if (replaceThreshold > 127) replaceThreshold = 127;
    }

    // ── Геттеры ────────────────────────────────────────────────────

    public static int getTargetStackSize() { return targetStackSize; }
    public static int getReplaceThreshold() { return replaceThreshold; }
    public static boolean isEnableLogging() { return enableLogging; }

    // ── Сеттеры (для /stack67 set) ─────────────────────────────────

    /**
     * Устанавливает targetStackSize и сохраняет в config.yml.
     */
    public static void setTargetStackSize(int value, FileConfiguration config) {
        targetStackSize = Math.max(1, Math.min(127, value));
        config.set("targetStackSize", targetStackSize);
    }
}

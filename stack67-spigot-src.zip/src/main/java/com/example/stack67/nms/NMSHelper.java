package com.example.stack67.nms;

import com.example.stack67.Stack67Plugin;
import com.example.stack67.config.Stack67SpigotConfig;
import org.bukkit.Material;
import org.bukkit.Bukkit;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.EnumMap;
import java.util.Map;

/**
 * ──────────────────────────────────────────────────────────────────────
 * NMSHelper — утилита для доступа к внутренним классам Minecraft
 * ──────────────────────────────────────────────────────────────────────
 *
 * Зачем нужен NMS-доступ:
 *   Bukkit API (Material.getMaxStackSize()) — метод ТОЛЬКО ДЛЯ ЧТЕНИЯ.
 *   Нельзя изменить размер стака через стандартный API.
 *   Поэтому мы обращаемся напрямую к внутренним классам Minecraft
 *   через reflection.
 *
 * Стратегия доступа:
 *   Используем reflection для доступа к приватному полю maxStackSize
 *   в классе net.minecraft.world.item.Item. Это работает на Paper 1.20.5+
 *   (Mojang mappings), а также на Spigot (обфусцированные имена).
 *
 * Совместимость с платформами:
 *   - Paper 1.20.5+:  CraftBukkit без versioned-пакетов,
 *                       Mojang mappings (поле = "maxStackSize")
 *   - Spigot 1.20.5+: CraftBukkit с versioned-пакетами,
 *                       SRG/обфусцированные имена полей
 *   - Автоопределение: плагин проверяет наличие Paper API
 *     и выбирает правильную стратегию
 *
 * Кэширование:
 *   - Оригинальные значения сохраняются в originalValues
 *   - При disable() — восстанавливаются
 *   - При reload() — восстанавливаются и применяются заново
 *
 * ВНИМАНИЕ: NMS-доступ хрупок и может ломаться при обновлении
 *           Minecraft. Проверяйте совместимость после каждого обновления!
 * ──────────────────────────────────────────────────────────────────────
 */
public class NMSHelper {

    private final Stack67Plugin plugin;

    /** Кэш оригинальных значений maxStackSize для восстановления */
    private final Map<Material, Integer> originalValues = new EnumMap<>(Material.class);

    /** Найденное поле maxStackSize в классе Item (кешируется) */
    private Field maxStackSizeField;

    /** Метод getItem(Material) из CraftMagicNumbers */
    private Method getItemMethod;

    /** Экземпляр CraftMagicNumbers (singleton) */
    private Object craftMagicNumbersInstance;

    /** Класс NMS Item (кешируется после первого поиска) */
    private Class<?> itemClass;

    /** Флаг: успешно ли инициализирован NMS-доступ */
    private boolean available = false;

    // ── Конструктор ─────────────────────────────────────────────────

    public NMSHelper(Stack67Plugin plugin) {
        this.plugin = plugin;
        initNMSAccess();
    }

    // ── Инициализация NMS-доступа ───────────────────────────────────

    /**
     * Инициализирует доступ к NMS-классу Item.
     * Пробует несколько стратегий для совместимости с разными версиями.
     *
     * Paper 1.20.5+ убрал versioned-пакеты CraftBukkit, поэтому
     * мы сначала пробуем безверсионный путь, а потом versioned.
     */
    private void initNMSAccess() {
        // ── Шаг 1: Находим CraftMagicNumbers и метод getItem() ──
        if (!initCraftMagicNumbers()) {
            plugin.getLogger().severe("Не удалось найти CraftMagicNumbers!");
            plugin.getLogger().severe("Плагин не может работать на этой версии.");
            return;
        }

        // ── Шаг 2: Определяем класс Item через возвращаемый тип getItem() ──
        itemClass = getItemMethod.getReturnType();
        plugin.getLogger().info("NMS Item class: " + itemClass.getName());

        // ── Шаг 3: Ищем поле maxStackSize в классе Item ──
        findMaxStackSizeField();

        if (maxStackSizeField != null) {
            available = true;
            plugin.getLogger().info("NMS-доступ успешно инициализирован");
        } else {
            plugin.getLogger().severe("Поле maxStackSize не найдено в " + itemClass.getName());
            plugin.getLogger().severe("Плагин не может работать на этой версии.");
        }
    }

    /**
     * Инициализирует доступ к CraftMagicNumbers.
     * Пробует безверсионный путь (Paper 1.20.5+) и versioned (Spigot).
     *
     * @return true если удалось найти CraftMagicNumbers и метод getItem()
     */
    private boolean initCraftMagicNumbers() {
        // Стратегия 1: Paper 1.20.5+ — без versioned-пакетов
        // Класс находится в org.bukkit.craftbukkit.util.CraftMagicNumbers
        try {
            Class<?> cmnClass = Class.forName(
                    "org.bukkit.craftbukkit.util.CraftMagicNumbers"
            );
            getItemMethod = cmnClass.getMethod("getItem", Material.class);

            // Paper: INSTANCE — публичное статическое поле
            try {
                Field instanceField = cmnClass.getField("INSTANCE");
                craftMagicNumbersInstance = instanceField.get(null);
            } catch (NoSuchFieldException e) {
                // Spigot без versioned: пробуем getDefault()
                try {
                    Method defaultMethod = cmnClass.getMethod("getDefault");
                    craftMagicNumbersInstance = defaultMethod.invoke(null);
                } catch (Exception e2) {
                    // Последняя попытка: создаём экземпляр
                    craftMagicNumbersInstance = cmnClass.getDeclaredConstructor().newInstance();
                }
            }

            plugin.getLogger().info("CraftMagicNumbers найден (Paper/unversioned)");
            return true;
        } catch (ClassNotFoundException e) {
            plugin.getLogger().info("Unversioned CraftMagicNumbers не найден, пробуем versioned...");
        } catch (Exception e) {
            plugin.getLogger().warning("Ошибка при доступе к unversioned CraftMagicNumbers: " + e.getMessage());
        }

        // Стратегия 2: Spigot — versioned-пакеты
        // Класс находится в org.bukkit.craftbukkit.v1_21_R1.util.CraftMagicNumbers
        String version = getNMSVersion();
        if (version != null && !version.isEmpty()) {
            try {
                Class<?> cmnClass = Class.forName(
                        "org.bukkit.craftbukkit." + version + ".util.CraftMagicNumbers"
                );
                getItemMethod = cmnClass.getMethod("getItem", Material.class);

                try {
                    Field instanceField = cmnClass.getField("INSTANCE");
                    craftMagicNumbersInstance = instanceField.get(null);
                } catch (NoSuchFieldException e) {
                    craftMagicNumbersInstance = cmnClass.getDeclaredConstructor().newInstance();
                }

                plugin.getLogger().info("CraftMagicNumbers найден (versioned: " + version + ")");
                return true;
            } catch (ClassNotFoundException e) {
                plugin.getLogger().warning("Versioned CraftMagicNumbers не найден: " + version);
            } catch (Exception e) {
                plugin.getLogger().warning("Ошибка при доступе к versioned CraftMagicNumbers: " + e.getMessage());
            }
        }

        // Стратегия 3: Fallback — прямой доступ к Item через Reflection
        // Используем Bukkit.getServer() для получения пути к NMS
        try {
            // Получаем CB пакет сервера
            String serverPkg = Bukkit.getServer().getClass().getPackage().getName();
            // serverPkg = org.bukkit.craftbukkit.v1_21_R1 или org.bukkit.craftbukkit
            String cbVersion = serverPkg.contains(".v") ? serverPkg.substring(serverPkg.lastIndexOf('.') + 1) : "";

            String cmnPath = serverPkg + ".util.CraftMagicNumbers";
            Class<?> cmnClass = Class.forName(cmnPath);
            getItemMethod = cmnClass.getMethod("getItem", Material.class);

            try {
                craftMagicNumbersInstance = cmnClass.getField("INSTANCE").get(null);
            } catch (NoSuchFieldException e) {
                craftMagicNumbersInstance = cmnClass.getDeclaredConstructor().newInstance();
            }

            plugin.getLogger().info("CraftMagicNumbers найден через server package: " + cmnPath);
            return true;
        } catch (Exception e) {
            plugin.getLogger().severe("Все стратегии поиска CraftMagicNumbers исчерпаны!");
            return false;
        }
    }

    /**
     * Ищет поле maxStackSize в классе Item.
     * Пробует несколько имён для разных mappings.
     */
    private void findMaxStackSizeField() {
        // Возможные имена поля в разных mappings:
        //   "maxStackSize"  — Mojang mappings (Paper)
        //   "f_41340_"      — SRG mappings (NeoForge intermediate)
        //   "d"             — Обфусцированное (старый Spigot)
        //   "c"             — Альтернативное обфусцированное
        String[] fieldNames = {
                "maxStackSize",    // Paper / Mojang mappings
                "f_41340_",        // SRG intermediate (NeoForge)
                "d",               // Spigot обфусцированное
                "c",               // Альтернативное обфусцированное
                "maxStack"         // Маловероятно, но возможно
        };

        for (String name : fieldNames) {
            try {
                Field f = itemClass.getDeclaredField(name);
                f.setAccessible(true);
                maxStackSizeField = f;
                plugin.getLogger().info("Поле maxStackSize найдено: '" + name + "' (тип: int)");
                return;
            } catch (NoSuchFieldException e) {
                // Пробуем следующее имя — это нормально
            } catch (SecurityException e) {
                plugin.getLogger().warning("SecurityManager заблокировал доступ к полю '" + name + "'");
            }
        }

        // Последняя попытка: ищем среди всех int-полей по эвристике
        // Ищем поле с модификатором private final int, значение которого
        // для STONE равно 64
        plugin.getLogger().info("Ищем поле maxStackSize по эвристике...");
        try {
            Object stoneItem = getNMSItem(Material.STONE);
            if (stoneItem != null) {
                for (Field f : itemClass.getDeclaredFields()) {
                    if (f.getType() == int.class) {
                        try {
                            f.setAccessible(true);
                            int val = f.getInt(stoneItem);
                            if (val == 64) {
                                // Проверяем, что это не durability (1) и не damage
                                // Камень имеет maxStackSize=64 — это кандидат
                                maxStackSizeField = f;
                                plugin.getLogger().info("Поле maxStackSize найдено по эвристике: '" + f.getName() + "'");
                                return;
                            }
                        } catch (Exception ignored) {}
                    }
                }
            }
        } catch (Exception e) {
            plugin.getLogger().warning("Эвристика не сработала: " + e.getMessage());
        }

        plugin.getLogger().warning("Поле maxStackSize НЕ НАЙДЕНО. Плагин не сможет изменять размер стака.");
    }

    // ── Изменение размера стака ─────────────────────────────────────

    /**
     * Устанавливает максимальный размер стака для указанного материала.
     *
     * Использует reflection для прямого изменения приватного поля
     * maxStackSize в NMS-классе Item.
     *
     * @param material  материал Bukkit
     * @param maxSize   новый максимальный размер
     * @return true если изменение прошло успешно
     */
    public boolean setMaxStackSize(Material material, int maxSize) {
        if (maxStackSizeField == null) return false;

        try {
            Object nmsItem = getNMSItem(material);
            if (nmsItem == null) return false;

            // Сохраняем оригинальное значение (только первый раз)
            originalValues.putIfAbsent(material, maxStackSizeField.getInt(nmsItem));

            // Устанавливаем новое значение
            maxStackSizeField.setInt(nmsItem, maxSize);

            if (Stack67SpigotConfig.isEnableLogging()) {
                plugin.getLogger().info("setMaxStackSize: " + material.name() +
                        " " + originalValues.get(material) + " → " + maxSize);
            }

            return true;

        } catch (IllegalAccessException e) {
            plugin.getLogger().warning("Reflection заблокирован для " + material.name() +
                    ": " + e.getMessage());
            return false;
        }
    }

    // ── Получение NMS Item ──────────────────────────────────────────

    /**
     * Получает NMS-экземпляр Item для данного Material.
     * Использует CraftMagicNumbers.getItem() — самый надёжный способ.
     */
    private Object getNMSItem(Material material) {
        if (getItemMethod == null || craftMagicNumbersInstance == null) return null;

        try {
            return getItemMethod.invoke(craftMagicNumbersInstance, material);
        } catch (Exception e) {
            if (Stack67SpigotConfig.isEnableLogging()) {
                plugin.getLogger().warning("Не удалось получить NMS Item для " + material.name() +
                        ": " + e.getMessage());
            }
            return null;
        }
    }

    // ── Восстановление ──────────────────────────────────────────────

    /**
     * Восстанавливает оригинальные значения maxStackSize.
     * Вызывается при disable() и перед reload().
     */
    public void restoreDefaults() {
        if (maxStackSizeField == null) return;

        int restored = 0;
        for (Map.Entry<Material, Integer> entry : originalValues.entrySet()) {
            try {
                Object nmsItem = getNMSItem(entry.getKey());
                if (nmsItem != null) {
                    maxStackSizeField.setInt(nmsItem, entry.getValue());
                    restored++;
                }
            } catch (Exception e) {
                plugin.getLogger().warning("Не удалось восстановить стак для " + entry.getKey().name());
            }
        }
        originalValues.clear();
        plugin.getLogger().info("Восстановлено предметов: " + restored);
    }

    // ── Утилитарные методы ──────────────────────────────────────────

    /**
     * Возвращает версию NMS (например, "v1_21_R1").
     * Работает только на Spigot с versioned-пакетами.
     * Paper 1.20.5+ не использует versioned-пакеты — вернёт пустую строку.
     */
    private String getNMSVersion() {
        try {
            String pkg = org.bukkit.Bukkit.getServer().getClass().getPackage().getName();
            String version = pkg.substring(pkg.lastIndexOf('.') + 1);
            // Если результат "craftbukkit" — значит безверсионный (Paper)
            if ("craftbukkit".equals(version)) return "";
            return version;
        } catch (Exception e) {
            return "";
        }
    }

    /**
     * Проверяет, был ли успешно инициализирован NMS-доступ.
     */
    public boolean isAvailable() {
        return available;
    }
}
